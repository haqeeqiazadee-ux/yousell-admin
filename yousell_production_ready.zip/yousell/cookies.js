/* ══════════════════════════════════════════════════════
   YouSell.Online — Cookie Consent System
   GDPR + CCPA compliant cookie banner and consent manager
   ══════════════════════════════════════════════════════ */

(function() {
  'use strict';

  const CONSENT_KEY = 'ys_cookie_consent';
  const isDashboard = window.location.pathname.includes('/dashboard/');

  // Detect Do Not Track
  const dnt = navigator.doNotTrack === '1' || window.doNotTrack === '1' || navigator.msDoNotTrack === '1';

  function getConsent() {
    try {
      const raw = localStorage.getItem(CONSENT_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch(e) { return null; }
  }

  function saveConsent(analytics, marketing) {
    const consent = {
      essential: true,
      analytics: analytics,
      marketing: marketing,
      saved: true,
      ts: Date.now()
    };
    try { localStorage.setItem(CONSENT_KEY, JSON.stringify(consent)); } catch(e) {}
    document.dispatchEvent(new CustomEvent('consentUpdated', { detail: consent }));
    return consent;
  }

  function removeBanner() {
    const banner = document.getElementById('ys-cookie-banner');
    const modal = document.getElementById('ys-cookie-modal');
    if (banner) { banner.style.transform = 'translateY(120%)'; banner.style.opacity = '0'; setTimeout(() => banner.remove(), 400); }
    if (modal) modal.remove();
  }

  function injectStyles() {
    if (document.getElementById('ys-cookie-styles')) return;
    const style = document.createElement('style');
    style.id = 'ys-cookie-styles';
    style.textContent = `
      #ys-cookie-banner {
        position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%) translateY(0);
        width: calc(100% - 48px); max-width: 780px; z-index: 99999;
        background: #13131f; border: 1px solid rgba(255,255,255,0.1);
        border-radius: 16px; padding: 20px 24px; box-shadow: 0 20px 60px rgba(0,0,0,0.6);
        display: flex; align-items: center; gap: 20px; flex-wrap: wrap;
        transition: transform 0.4s cubic-bezier(0.16,1,0.3,1), opacity 0.4s ease;
        animation: ys-slide-up 0.5s cubic-bezier(0.16,1,0.3,1) forwards;
      }
      @keyframes ys-slide-up { from { transform: translateX(-50%) translateY(120%); opacity:0; } to { transform: translateX(-50%) translateY(0); opacity:1; } }
      #ys-cookie-banner p { margin:0; font-family:'DM Sans',sans-serif; font-size:13px; color:#9898b8; flex:1; min-width:200px; line-height:1.6; }
      #ys-cookie-banner p a { color:#e94560; text-decoration:none; }
      #ys-cookie-banner p a:hover { text-decoration:underline; }
      .ys-cookie-actions { display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
      .ys-btn-accept { background:#e94560; color:#fff; border:none; border-radius:8px; padding:10px 20px; font-family:'DM Sans',sans-serif; font-size:13px; font-weight:600; cursor:pointer; transition:background 0.2s; white-space:nowrap; }
      .ys-btn-accept:hover { background:#c73652; }
      .ys-btn-customise { background:transparent; color:#e8e8f2; border:1px solid rgba(255,255,255,0.15); border-radius:8px; padding:10px 16px; font-family:'DM Sans',sans-serif; font-size:13px; font-weight:500; cursor:pointer; transition:border-color 0.2s; white-space:nowrap; }
      .ys-btn-customise:hover { border-color:rgba(255,255,255,0.35); }
      .ys-dnsmpi { font-size:11px !important; color:#55556a !important; display:block; margin-top:6px; }

      /* Modal */
      #ys-cookie-modal { position:fixed; inset:0; z-index:100000; display:flex; align-items:center; justify-content:center; padding:20px; }
      .ys-modal-backdrop { position:absolute; inset:0; background:rgba(0,0,0,0.75); backdrop-filter:blur(4px); }
      .ys-modal-box { position:relative; background:#13131f; border:1px solid rgba(255,255,255,0.1); border-radius:20px; padding:32px; max-width:500px; width:100%; box-shadow:0 30px 80px rgba(0,0,0,0.7); animation:ys-modal-in 0.35s cubic-bezier(0.16,1,0.3,1); }
      @keyframes ys-modal-in { from { transform:scale(0.94) translateY(20px); opacity:0; } to { transform:scale(1) translateY(0); opacity:1; } }
      .ys-modal-title { font-family:'Outfit',sans-serif; font-size:20px; font-weight:700; color:#fff; margin:0 0 6px; }
      .ys-modal-sub { font-family:'DM Sans',sans-serif; font-size:13px; color:#9898b8; margin:0 0 24px; line-height:1.6; }
      .ys-toggle-row { display:flex; align-items:flex-start; justify-content:space-between; gap:16px; padding:16px 0; border-top:1px solid rgba(255,255,255,0.06); }
      .ys-toggle-info strong { font-family:'DM Sans',sans-serif; font-size:14px; font-weight:600; color:#e8e8f2; display:block; margin-bottom:3px; }
      .ys-toggle-info span { font-family:'DM Sans',sans-serif; font-size:12px; color:#55556a; line-height:1.5; display:block; }
      .ys-toggle-wrap { position:relative; flex-shrink:0; margin-top:2px; }
      .ys-toggle { appearance:none; -webkit-appearance:none; width:44px; height:24px; border-radius:12px; background:#252540; cursor:pointer; transition:background 0.25s; border:none; outline:none; }
      .ys-toggle:checked { background:#e94560; }
      .ys-toggle:disabled { opacity:0.4; cursor:not-allowed; }
      .ys-toggle::after { content:''; position:absolute; top:3px; left:3px; width:18px; height:18px; border-radius:50%; background:#fff; transition:transform 0.25s cubic-bezier(0.34,1.56,0.64,1); pointer-events:none; }
      .ys-toggle:checked::after { transform:translateX(20px); }
      .ys-always-on { font-family:'DM Sans',sans-serif; font-size:11px; color:#55556a; margin-top:4px; text-align:right; white-space:nowrap; }
      .ys-modal-actions { display:flex; gap:10px; margin-top:24px; }
      .ys-btn-save-all { flex:1; background:#e94560; color:#fff; border:none; border-radius:8px; padding:12px; font-family:'DM Sans',sans-serif; font-size:14px; font-weight:600; cursor:pointer; transition:background 0.2s; }
      .ys-btn-save-all:hover { background:#c73652; }
      .ys-btn-save-prefs { flex:1; background:rgba(255,255,255,0.05); color:#e8e8f2; border:1px solid rgba(255,255,255,0.12); border-radius:8px; padding:12px; font-family:'DM Sans',sans-serif; font-size:14px; font-weight:500; cursor:pointer; transition:background 0.2s; }
      .ys-btn-save-prefs:hover { background:rgba(255,255,255,0.09); }
      @media(max-width:600px) {
        #ys-cookie-banner { bottom:12px; left:12px; right:12px; width:auto; transform:none; animation:ys-slide-up-mob 0.5s cubic-bezier(0.16,1,0.3,1) forwards; }
        @keyframes ys-slide-up-mob { from { transform:translateY(120%); opacity:0; } to { transform:translateY(0); opacity:1; } }
        #ys-cookie-banner { flex-direction:column; align-items:flex-start; }
        .ys-cookie-actions { width:100%; }
        .ys-btn-accept, .ys-btn-customise { flex:1; text-align:center; }
      }
    `;
    document.head.appendChild(style);
  }

  function showBanner() {
    injectStyles();

    const banner = document.createElement('div');
    banner.id = 'ys-cookie-banner';
    banner.setAttribute('role', 'region');
    banner.setAttribute('aria-label', 'Cookie consent');

    if (isDashboard) {
      banner.innerHTML = `
        <p>This dashboard uses essential cookies only to keep you logged in. No tracking or advertising cookies are used in the client portal.</p>
        <div class="ys-cookie-actions">
          <button class="ys-btn-accept" id="ys-accept-essential">Got It</button>
        </div>
      `;
      document.body.appendChild(banner);
      document.getElementById('ys-accept-essential').addEventListener('click', function() {
        saveConsent(false, false);
        removeBanner();
      });
      return;
    }

    banner.innerHTML = `
      <p>
        We use essential, analytics, and marketing cookies to improve your experience.
        See our <a href="/privacy-policy/">Cookie Policy</a> and <a href="/privacy-policy/">Privacy Policy</a>.
        <a href="/privacy-policy/#do-not-sell" class="ys-dnsmpi">Do Not Sell My Personal Information</a>
      </p>
      <div class="ys-cookie-actions">
        <button class="ys-btn-customise" id="ys-customise-btn">Customise</button>
        <button class="ys-btn-accept" id="ys-accept-all-btn">Accept All</button>
      </div>
    `;
    document.body.appendChild(banner);

    document.getElementById('ys-accept-all-btn').addEventListener('click', function() {
      saveConsent(true, true);
      removeBanner();
    });

    document.getElementById('ys-customise-btn').addEventListener('click', function() {
      showModal();
    });
  }

  function showModal() {
    injectStyles();
    const existing = getConsent();

    const modal = document.createElement('div');
    modal.id = 'ys-cookie-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Cookie preferences');

    const analyticsDefault = existing ? existing.analytics : !dnt;
    const marketingDefault = existing ? existing.marketing : false;

    modal.innerHTML = `
      <div class="ys-modal-backdrop" id="ys-modal-backdrop"></div>
      <div class="ys-modal-box">
        <div class="ys-modal-title">Cookie Preferences</div>
        <p class="ys-modal-sub">Choose which cookies you allow. Essential cookies cannot be disabled as they are required for the site to function.</p>

        <div class="ys-toggle-row">
          <div class="ys-toggle-info">
            <strong>Essential Cookies</strong>
            <span>Required for the website to function. Login sessions, security, form submissions.</span>
          </div>
          <div>
            <input type="checkbox" class="ys-toggle" id="ys-t-essential" checked disabled aria-label="Essential cookies - always on">
            <div class="ys-always-on">Always on</div>
          </div>
        </div>

        <div class="ys-toggle-row">
          <div class="ys-toggle-info">
            <strong>Analytics Cookies</strong>
            <span>Google Analytics, TikTok Pixel, Meta Pixel. Help us understand how visitors use our site.</span>
          </div>
          <div>
            <input type="checkbox" class="ys-toggle" id="ys-t-analytics" ${analyticsDefault ? 'checked' : ''} aria-label="Analytics cookies">
          </div>
        </div>

        <div class="ys-toggle-row">
          <div class="ys-toggle-info">
            <strong>Marketing Cookies</strong>
            <span>Retargeting ads on social media and search. Allows personalised advertising across platforms.</span>
          </div>
          <div>
            <input type="checkbox" class="ys-toggle" id="ys-t-marketing" ${marketingDefault ? 'checked' : ''} aria-label="Marketing cookies">
          </div>
        </div>

        <div class="ys-modal-actions">
          <button class="ys-btn-save-prefs" id="ys-save-prefs">Save Preferences</button>
          <button class="ys-btn-save-all" id="ys-accept-all-modal">Accept All</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('ys-modal-backdrop').addEventListener('click', function() {
      modal.remove();
    });

    document.getElementById('ys-save-prefs').addEventListener('click', function() {
      const analytics = document.getElementById('ys-t-analytics').checked;
      const marketing = document.getElementById('ys-t-marketing').checked;
      saveConsent(analytics, marketing);
      removeBanner();
      modal.remove();
    });

    document.getElementById('ys-accept-all-modal').addEventListener('click', function() {
      saveConsent(true, true);
      removeBanner();
      modal.remove();
    });
  }

  // Init
  function init() {
    const consent = getConsent();
    if (!consent || !consent.saved) {
      showBanner();
    }
    // Expose API for external use
    window.YSCookies = {
      getConsent: getConsent,
      showPreferences: showModal,
      hasAnalyticsConsent: function() { const c = getConsent(); return c && c.analytics; },
      hasMarketingConsent: function() { const c = getConsent(); return c && c.marketing; }
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
