/**
 * YouSell Email Triggers — Client Module
 * ══════════════════════════════════════════════════════════
 * Add this to your dashboard pages:
 *   <script src="email-triggers.js"></script>
 *
 * This module fires emails at the right moments in the
 * customer journey by calling the email service API.
 *
 * The email service URL and secret are set in your .env
 * and baked in at build time, OR you can set them here:
 *
 *   window.YS_EMAIL_SERVICE_URL    = 'https://your-service.com';
 *   window.YS_EMAIL_SERVICE_SECRET = 'your-secret';
 *
 * Both are required for emails to send.
 * If either is missing, triggers fail silently (no errors thrown).
 */

const EmailTriggers = (() => {
  'use strict';

  // ── Config ─────────────────────────────────────────────
  const SERVICE_URL = window.YS_EMAIL_SERVICE_URL    || '';
  const SECRET      = window.YS_EMAIL_SERVICE_SECRET  || '';

  // ── Helpers ────────────────────────────────────────────

  async function _post(endpoint, body) {
    if (!SERVICE_URL || !SECRET) return null;
    try {
      const res = await fetch(`${SERVICE_URL}${endpoint}`, {
        method:  'POST',
        headers: {
          'Content-Type':           'application/json',
          'x-email-service-token':  SECRET
        },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (data.ok) {
        console.log(`[EmailTriggers] ✓ ${endpoint} sent (subject: "${data.subject}")`);
      } else {
        console.warn(`[EmailTriggers] ${endpoint} failed:`, data.error);
      }
      return data;
    } catch(e) {
      console.warn(`[EmailTriggers] ${endpoint} error:`, e.message);
      return null;
    }
  }

  async function _getCurrentUser() {
    if (typeof Auth === 'undefined') return null;
    const session = await Auth.check();
    if (!session) return null;
    return { email: session.email, name: session.name };
  }

  // ── Deduplication ──────────────────────────────────────
  // Prevents the same trigger firing twice in the same session.
  const _fired = new Set();
  function _once(key, fn) {
    const storageKey = 'ys_email_fired_' + key;
    if (_fired.has(key) || localStorage.getItem(storageKey)) return;
    _fired.add(key);
    localStorage.setItem(storageKey, '1');
    return fn();
  }

  // ══════════════════════════════════════════════════════
  // PUBLIC TRIGGERS
  // ══════════════════════════════════════════════════════

  /**
   * Fire when a new account is created.
   * Called from: login.html → after successful Auth.signup()
   *
   * @param {string} email
   * @param {string} name       — user's full name
   * @param {string} service    — e.g. "Amazon Services", "TikTok Shop"
   */
  async function onAccountCreated(email, name, service) {
    return _once(`account-created-${email}`, () =>
      _post('/email/account-created', { email, name, service })
    );
  }

  /**
   * Fire when a platform is connected.
   * Called from: dashboard.js → handleConnect()
   *
   * @param {string} platform   — "Amazon" | "TikTok" | "Shopify"
   * @param {string} storeName  — optional store/shop name
   */
  async function onPlatformConnected(platform, storeName) {
    const user = await _getCurrentUser();
    if (!user) return;
    return _once(`platform-connected-${user.email}-${platform}`, () =>
      _post('/email/platform-connected', {
        email: user.email,
        name:  user.name,
        platform,
        storeName,
        connectedAt: new Date().toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })
      })
    );
  }

  /**
   * Fire on first sale detected for a platform.
   * Called from: dashboard page → when order count transitions from 0 to 1
   *
   * @param {string} platform   — "Amazon" | "TikTok" | "Shopify"
   * @param {string} amount     — e.g. "$89.90"
   * @param {string} product    — product name
   */
  async function onFirstSale(platform, amount, product) {
    const user = await _getCurrentUser();
    if (!user) return;
    return _once(`first-sale-${user.email}-${platform}`, () =>
      _post('/email/first-sale', {
        email: user.email,
        name:  user.name,
        platform, amount, product,
        saleTime: new Date().toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })
      })
    );
  }

  /**
   * Fire when a revenue milestone is hit.
   * Called from: dashboard pages → after data loads, check milestones
   *
   * @param {string} milestone       — e.g. "First $10,000 month"
   * @param {string} platform        — platform or "All Platforms"
   * @param {string} timeToMilestone — e.g. "6 weeks"
   */
  async function onMilestone(milestone, platform, timeToMilestone) {
    const user = await _getCurrentUser();
    if (!user) return;
    const key = `milestone-${user.email}-${milestone.replace(/\W/g,'')}`;
    return _once(key, () =>
      _post('/email/milestone', {
        email: user.email,
        name:  user.name,
        milestone, platform, timeToMilestone
      })
    );
  }

  /**
   * Fire when a platform issue is detected.
   * Called from: dashboard pages → on API error or health warning
   *
   * @param {string} platform   — "Amazon" | "TikTok" | "Shopify"
   * @param {string} issueType  — e.g. "Account Health Warning"
   * @param {string} severity   — "low" | "medium" | "high" | "critical"
   * @param {string} action     — recommended action text
   */
  async function onPlatformIssue(platform, issueType, severity, action) {
    const user = await _getCurrentUser();
    if (!user) return;
    // Don't dedup platform issues — they should always send
    return _post('/email/platform-issue', {
      email: user.email,
      name:  user.name,
      platform, issueType, severity, action,
      detectedAt: new Date().toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })
    });
  }

  /**
   * Auto-detect milestones from live dashboard data.
   * Call this after loading any platform's data.
   *
   * @param {string} platform
   * @param {object} data       — the loaded metrics object
   */
  async function checkMilestones(platform, data) {
    if (!data) return;

    const milestones = {
      Amazon: [
        { key: '1k',  threshold: 1000,   label: 'First $1,000 in Amazon revenue' },
        { key: '5k',  threshold: 5000,   label: 'First $5,000 in Amazon revenue' },
        { key: '10k', threshold: 10000,  label: 'First $10,000 Amazon month'      },
        { key: '25k', threshold: 25000,  label: '$25,000 Amazon milestone'         },
        { key: '50k', threshold: 50000,  label: '$50,000 Amazon milestone'         },
      ],
      TikTok: [
        { key: '1k',   threshold: 1000,   label: 'First $1,000 TikTok GMV'  },
        { key: '10k',  threshold: 10000,  label: '$10,000 TikTok GMV month'  },
        { key: '50k',  threshold: 50000,  label: '$50,000 TikTok GMV'        },
        { key: 'c100', threshold: 100,    label: '100 TikTok orders',  field: 'orders' },
      ],
      Shopify: [
        { key: '1k',  threshold: 1000,   label: 'First $1,000 Shopify revenue' },
        { key: '5k',  threshold: 5000,   label: '$5,000 Shopify milestone'      },
        { key: '500', threshold: 500,    label: '500 Shopify orders',  field: 'orders' },
      ]
    };

    const checks = milestones[platform] || [];
    for (const m of checks) {
      const val = data[m.field || 'revenue'] || data[m.field || 'gmv'] || 0;
      if (val >= m.threshold) {
        await onMilestone(m.label, platform);
      }
    }

    // First sale detection
    const orderCount = data.orders || 0;
    if (orderCount >= 1) {
      const topProduct = data.bsr?.[0]?.title || data.topProducts?.[0]?.name || data.topVideos?.[0]?.creator || '';
      await onFirstSale(
        platform,
        '$' + (data.revenue || data.gmv || 0).toLocaleString(),
        topProduct
      );
    }
  }

  // ══════════════════════════════════════════════════════
  // AUTO-INIT
  // Hooks into existing dashboard.js functions at page load
  // ══════════════════════════════════════════════════════
  function init() {
    // Patch handleConnect to fire platform-connected email
    if (typeof handleConnect !== 'undefined') {
      const _origConnect = handleConnect;
      window.handleConnect = async function(platform, formData) {
        await onPlatformConnected(platform, formData.storeName || formData.shopDomain);
        return _origConnect(platform, formData);
      };
    }

    // Watch for URL-based triggers (e.g. ?welcome=1 after signup)
    const params = new URLSearchParams(window.location.search);
    if (params.get('welcome') === '1') {
      const email = params.get('email');
      const name  = params.get('name');
      const svc   = params.get('service');
      if (email && name) onAccountCreated(email, decodeURIComponent(name), svc);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // ── Public API ─────────────────────────────────────────
  return {
    onAccountCreated,
    onPlatformConnected,
    onFirstSale,
    onMilestone,
    onPlatformIssue,
    checkMilestones
  };

})();

// Make available globally
window.EmailTriggers = EmailTriggers;
