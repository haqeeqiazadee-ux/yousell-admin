# YouSell Email Automation Service

AI-powered lifecycle emails using **Claude** (content), **Resend** (delivery), and **Supabase** (data).

---

## What it does

Every email is written in real-time by Claude — personalised with the client's name, platform, and actual metrics. If Claude is unavailable, it falls back to polished pre-written templates automatically.

### Email Journey Map

```
Account Created          → Welcome email (immediate)
                         → Onboarding Step 1 (30 min later)
                         → Onboarding Step 2 (48h after step 1)
                         → Onboarding Step 3 (72h after step 2)
                         → Onboarding Step 4 (96h after step 3)
                         → Onboarding Step 5 (120h after step 4)

Platform Connected       → Connection confirmed email (immediate)

First Sale Detected      → Celebration email (immediate)

Milestone Hit            → Milestone email (immediate)
                           Thresholds: $1K, $5K, $10K, $25K, $50K revenue
                           or 100/500 orders, first sale

Weekly (every Monday)    → AI-written weekly report with live metrics

Platform Issue Detected  → Alert email (immediate, any severity)

Inactive 7+ days         → Re-engagement email (daily check at 10:00 EST)
```

---

## Setup (5 steps)

### 1. Get your API keys

| Service | Where to get it | Purpose |
|---------|----------------|---------|
| **Anthropic** | console.anthropic.com → API Keys | AI email content |
| **Resend** | resend.com → API Keys | Email delivery |
| **Supabase** | your project → Settings → API (use **service_role** key) | Data + logging |

### 2. Verify your sending domain on Resend

Go to **resend.com → Domains** and add `yousell.online`.
Add the DNS records Resend provides. Takes ~5 minutes to verify.

### 3. Run the database schema

Open **supabase.com → your project → SQL Editor** and run the contents of `schema.sql`.

This creates:
- `ys_email_log` — every email sent, with status
- `ys_email_subscriptions` — client preferences and state

### 4. Configure environment variables

```bash
cd dashboard/email-service
cp .env.example .env
# Edit .env with your real values
```

### 5. Start the service

```bash
npm install
npm start
```

---

## Add email-triggers.js to dashboard pages

Add to all 8 dashboard HTML pages, just before `</body>`:

```html
<script>
  // Set these before loading email-triggers.js
  window.YS_EMAIL_SERVICE_URL    = 'https://your-email-service.railway.app';
  window.YS_EMAIL_SERVICE_SECRET = 'your-secret-from-env';
</script>
<script src="email-triggers.js"></script>
```

Then in your page-specific scripts, call triggers at the right moments:

```javascript
// After signup
const result = await Auth.signup(email, password, name);
if (result.ok) {
  await EmailTriggers.onAccountCreated(email, name, selectedService);
}

// After platform data loads — auto-detects milestones and first sale
const data = await loadAmazonData();
await EmailTriggers.checkMilestones('Amazon', data);

// On platform error
await EmailTriggers.onPlatformIssue('Amazon', 'Account Health Warning', 'high', 'Review your account health in Seller Central immediately.');
```

---

## Deploying the email service

The email service is a standalone Node.js app. Deploy it separately from your Netlify site.

**Recommended: Railway (simplest)**
1. Push `dashboard/email-service/` to a GitHub repo
2. Connect to Railway → New Project → Deploy from GitHub
3. Add environment variables in Railway dashboard
4. Railway gives you a URL like `https://yousell-email.railway.app`

**Alternative: Render, Fly.io, or any VPS**

---

## Testing

```bash
# Test account-created email
curl -X POST http://localhost:3002/email/account-created \
  -H "Content-Type: application/json" \
  -H "x-email-service-token: your-secret" \
  -d '{"email":"test@example.com","name":"Alex Smith","service":"TikTok Shop"}'

# Test weekly report
curl -X POST http://localhost:3002/email/weekly-report \
  -H "Content-Type: application/json" \
  -H "x-email-service-token: your-secret" \
  -d '{"email":"test@example.com","name":"Alex Smith","amazon":{"revenue":"$8,420","change":"+12%"},"tiktok":{"gmv":"$14,200","change":"+31%"},"totalRevenue":"$22,620"}'

# Check service health
curl http://localhost:3002/health

# View email log
curl http://localhost:3002/email/log \
  -H "x-email-service-token: your-secret"
```

---

## Customising the AI prompts

All prompts are in `server.js` inside `AIWriter._buildPrompt()`. Each template has its own detailed prompt. Edit the brand voice, length, or content requirements directly in the prompt strings.

The current brand voice instructions:
> "Confident, expert, warm, conversational. Never corporate or salesy."

---

## Email log analytics

Run in Supabase SQL Editor:

```sql
-- Overall delivery summary
SELECT * FROM ys_email_analytics;

-- Recent emails
SELECT template, subject, status, sent_at
FROM ys_email_log
ORDER BY sent_at DESC
LIMIT 20;

-- Emails to a specific client
SELECT template, subject, status, sent_at
FROM ys_email_log
WHERE recipient_email = 'client@example.com'
ORDER BY sent_at DESC;
```
