/**
 * YouSell Email Automation Service
 * ══════════════════════════════════════════════════════════
 * AI-powered transactional + lifecycle emails using:
 *   • Resend (email delivery)     → resend.com
 *   • Anthropic Claude API        → AI-written personalised content
 *   • Supabase                    → event triggers & subscriber state
 *
 * SETUP:
 *   cd dashboard/email-service
 *   npm install
 *   cp .env.example .env    ← fill in your keys
 *   node server.js          ← or deploy to Railway / Render / Fly.io
 *
 * TRIGGER ENDPOINTS (called from dashboard.js):
 *   POST /email/account-created
 *   POST /email/platform-connected
 *   POST /email/first-sale
 *   POST /email/weekly-report
 *   POST /email/milestone
 *   POST /email/idle-warning
 *   POST /email/platform-issue
 *   POST /email/onboarding/:step
 *
 * CRON JOBS (internal, run automatically):
 *   Weekly reports      — every Monday 08:00
 *   Re-engagement       — users inactive 7 days
 *   Monthly summary     — 1st of each month
 */

'use strict';

require('dotenv').config();
const express    = require('express');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const Anthropic  = require('@anthropic-ai/sdk');
const { Resend } = require('resend');
const { createClient } = require('@supabase/supabase-js');
const cron       = require('node-cron');

const app  = express();
const PORT = process.env.EMAIL_SERVICE_PORT || 3002;

// ── CLIENTS ──────────────────────────────────────────────
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const resend    = new Resend(process.env.RESEND_API_KEY);
const supabase  = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY  // service role — never expose to browser
);

// ── MIDDLEWARE ────────────────────────────────────────────
app.use(helmet());
app.use(express.json({ limit: '50kb' }));

// Rate limit: 60 email requests per minute per IP
app.use('/email/', rateLimit({
  windowMs: 60 * 1000, max: 60, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many email requests. Slow down.' }
}));

// Internal auth — all requests must include the service secret
app.use('/email/', (req, res, next) => {
  const token = req.headers['x-email-service-token'];
  if (token !== process.env.EMAIL_SERVICE_SECRET) {
    return res.status(401).json({ error: 'Unauthorised' });
  }
  next();
});

// Request logger
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// ══════════════════════════════════════════════════════════
// AI EMAIL WRITER
// Calls Claude to write personalised email content.
// Falls back to pre-written templates if AI is unavailable.
// ══════════════════════════════════════════════════════════
const AIWriter = {

  async writeEmail(template, context) {
    const prompt = this._buildPrompt(template, context);
    try {
      const msg = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }]
      });
      const raw = msg.content[0].text.trim();
      return this._parseAIResponse(raw);
    } catch (e) {
      console.warn('[AIWriter] Claude unavailable, using fallback template:', e.message);
      return Templates.fallback(template, context);
    }
  },

  _buildPrompt(template, ctx) {
    const brand = `
YouSell.Online is an AI-powered ecommerce agency that manages Amazon, TikTok Shop, and Shopify stores for clients.
Brand voice: confident, expert, warm, conversational. Never corporate or salesy.
The client's first name is: ${ctx.firstName || ctx.name || 'there'}.
`;
    const prompts = {

      'account-created': `${brand}
Write a welcome email for a new YouSell client who just created their dashboard account.
Their name is ${ctx.firstName}. They signed up to get help with: ${ctx.service || 'ecommerce services'}.

The email should:
- Open with a warm, personal welcome (no generic "welcome to the platform" openers)
- Tell them exactly what happens in the next 24 hours (onboarding call, setup begins)
- List 3 specific things the YouSell team will do for them in the first week
- Include one piece of genuinely useful ecommerce advice relevant to their chosen service (${ctx.service || 'ecommerce'})
- End with a direct line to reach their account manager: admin@yousell.online
- Be 200-280 words. Conversational. No filler.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}
The body_html should use simple inline-styled HTML paragraphs and bullet lists. Dark background is #0d0d14, text is #e8e8f2, accent is #e94560.`,

      'platform-connected': `${brand}
Write an email confirming that ${ctx.firstName}'s ${ctx.platform} account has been successfully connected to their YouSell dashboard.

Context:
- Platform: ${ctx.platform}
- Connection time: ${ctx.connectedAt || 'just now'}
- Their store/shop: ${ctx.storeName || 'their store'}

The email should:
- Confirm the connection with specific technical detail (what data is now syncing)
- Tell them what they'll see in their dashboard within the next 30 minutes
- Give them 2-3 actionable next steps specific to ${ctx.platform}
- Mention the YouSell team will review their account data and be in touch within 4 hours
- Be 150-200 words. Punchy. Technical but readable.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`,

      'first-sale': `${brand}
Write an email celebrating ${ctx.firstName}'s FIRST SALE on ${ctx.platform}!

Details:
- Platform: ${ctx.platform}
- Sale amount: ${ctx.amount || 'their first order'}
- Product: ${ctx.product || 'their product'}
- Time of sale: ${ctx.saleTime || 'just now'}

The email should:
- Open with genuine excitement — this is a real milestone
- Give brief context on why the first sale matters (proof of concept, algorithm signal, momentum)
- Tell them what the YouSell team is doing RIGHT NOW to capitalise on this momentum
- Give them one specific action they can take today to accelerate to their second sale
- Be celebratory but grounded in strategy. 150-180 words.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`,

      'weekly-report': `${brand}
Write a weekly performance summary email for ${ctx.firstName}.

This week's metrics:
- Amazon revenue: ${ctx.amazon?.revenue || 'N/A'} (${ctx.amazon?.change || ''} vs last week)
- TikTok GMV: ${ctx.tiktok?.gmv || 'N/A'} (${ctx.tiktok?.change || ''} vs last week)
- Shopify revenue: ${ctx.shopify?.revenue || 'N/A'} (${ctx.shopify?.change || ''} vs last week)
- Total combined revenue: ${ctx.totalRevenue || 'N/A'}
- Top performing product: ${ctx.topProduct || 'N/A'}
- Notable events this week: ${ctx.highlights || 'None'}

The email should:
- Open with a one-sentence summary of the week (good, mixed, or needs attention — be honest)
- Present the numbers clearly but briefly
- Identify the ONE biggest opportunity for next week with specific reasoning
- Flag any issues that need their attention (if any)
- Close with what the YouSell team is working on for them next week
- Be 200-250 words. Data-forward. Honest.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`,

      'milestone': `${brand}
Write an email celebrating a revenue milestone for ${ctx.firstName}.

Milestone details:
- Milestone: ${ctx.milestone} (e.g. "First $10,000 month", "100 orders", "1,000 TikTok units sold")
- Platform: ${ctx.platform || 'across all platforms'}
- Time to reach milestone: ${ctx.timeToMilestone || 'since launch'}
- What it took: ${ctx.context || 'consistent effort and the right strategy'}

The email should:
- Open with a genuine, specific celebration of this milestone
- Put it in context — what % of sellers reach this? What does this unlock?
- Tell them the next milestone to aim for and a specific path to get there
- Be inspiring but grounded. No empty hype. 150-200 words.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`,

      'idle-warning': `${brand}
Write a re-engagement email for ${ctx.firstName}, who hasn't logged into their dashboard in ${ctx.daysSinceLogin || 7} days.

Context:
- Days inactive: ${ctx.daysSinceLogin}
- Their active platforms: ${ctx.platforms || 'Amazon, TikTok Shop, Shopify'}
- Last action taken: ${ctx.lastAction || 'connected their platforms'}

The email should:
- Be direct but warm — not guilt-tripping
- Tell them something specific that's happened in their store while they were away (use mock data if needed)
- Give them one compelling reason to log in TODAY
- Include their dashboard link: https://yousell.online/dashboard/
- Be 120-150 words. Short. High urgency.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`,

      'platform-issue': `${brand}
Write a proactive alert email to ${ctx.firstName} about an issue detected with their ${ctx.platform} account.

Issue details:
- Platform: ${ctx.platform}
- Issue type: ${ctx.issueType} (e.g. "account health warning", "low inventory", "API disconnected", "PPC budget depleted")
- Severity: ${ctx.severity || 'medium'} (low/medium/high/critical)
- Detected at: ${ctx.detectedAt || 'just now'}
- Recommended action: ${ctx.action || 'review account'}

The email should:
- State the issue clearly in the subject and first sentence — no burying the lede
- Explain what this means in plain English (impact if not addressed)
- Give 1-3 specific steps they can take RIGHT NOW
- Reassure them the YouSell team is monitoring and will be in touch
- Be calm but urgent. 120-160 words. No panic, no vagueness.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`,

      'onboarding-step': `${brand}
Write an onboarding sequence email for ${ctx.firstName}. This is step ${ctx.step} of 5 in their onboarding journey.

Step details:
- Step ${ctx.step}: ${ctx.stepTitle}
- What's been completed so far: ${ctx.completedSteps || 'account created'}
- What they need to do in this step: ${ctx.action}
- Estimated time to complete: ${ctx.timeEstimate || '10 minutes'}
- Why this step matters: ${ctx.why}

The email should:
- Reference their progress (${ctx.step - 1} of 5 steps done — great work)
- Explain clearly what to do in this step with numbered instructions if needed
- Make it feel achievable — not overwhelming
- Include a direct CTA button text to their dashboard: https://yousell.online/dashboard/
- Be 150-200 words. Encouraging. Action-focused.

Respond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`
    };

    return prompts[template] || `${brand}\nWrite a brief, professional email update for ${ctx.firstName} about their YouSell account. Context: ${JSON.stringify(ctx)}\n\nRespond ONLY with valid JSON: {"subject": "...", "preview": "...", "body_html": "..."}`;
  },

  _parseAIResponse(raw) {
    try {
      // Strip markdown code fences if present
      const cleaned = raw.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
      return JSON.parse(cleaned);
    } catch(e) {
      console.error('[AIWriter] Failed to parse AI response:', raw.slice(0, 200));
      return { subject: 'Update from YouSell', preview: 'News about your store.', body_html: `<p>${raw}</p>` };
    }
  }
};

// ══════════════════════════════════════════════════════════
// EMAIL RENDERER
// Wraps AI-generated body_html in the YouSell branded template.
// ══════════════════════════════════════════════════════════
const EmailRenderer = {
  wrap(content, opts = {}) {
    const { subject, body_html, ctaText, ctaUrl, footer_note } = content;
    const year = new Date().getFullYear();

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <meta name="color-scheme" content="dark light">
  <title>${subject}</title>
  <style>
    body { margin:0; padding:0; background:#0d0d14; font-family:'DM Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; -webkit-text-size-adjust:100%; }
    .wrapper { max-width:600px; margin:0 auto; padding:32px 16px; }
    .card { background:#13131f; border:1px solid rgba(255,255,255,0.07); border-radius:16px; overflow:hidden; }
    .header { background:linear-gradient(135deg,#13131f 0%,#1a1a2e 100%); padding:28px 32px; border-bottom:1px solid rgba(255,255,255,0.06); }
    .logo { font-size:22px; font-weight:900; letter-spacing:-0.5px; text-decoration:none; }
    .logo-you { color:#e94560; }
    .logo-rest { color:#e8e8f2; }
    .body { padding:32px; }
    .body p { color:#c8c8e0; font-size:15px; line-height:1.7; margin:0 0 16px; }
    .body strong { color:#e8e8f2; }
    .body ul { color:#c8c8e0; font-size:15px; line-height:1.8; padding-left:20px; margin:0 0 16px; }
    .body li { margin-bottom:6px; }
    .cta-wrap { text-align:center; margin:28px 0 8px; }
    .cta-btn { display:inline-block; background:#e94560; color:#ffffff !important; text-decoration:none; font-size:15px; font-weight:700; padding:14px 32px; border-radius:10px; letter-spacing:-0.2px; }
    .divider { border:none; border-top:1px solid rgba(255,255,255,0.06); margin:24px 0; }
    .footer { padding:20px 32px; text-align:center; }
    .footer p { color:#55556a; font-size:12px; line-height:1.7; margin:0 0 6px; }
    .footer a { color:#55556a; text-decoration:underline; }
    .stat-row { display:flex; gap:12px; margin:20px 0; flex-wrap:wrap; }
    .stat-box { flex:1; min-width:120px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:10px; padding:14px 16px; text-align:center; }
    .stat-box .val { color:#e8e8f2; font-size:22px; font-weight:800; letter-spacing:-0.5px; display:block; }
    .stat-box .lbl { color:#55556a; font-size:11px; font-weight:600; letter-spacing:0.5px; text-transform:uppercase; display:block; margin-top:4px; }
    .stat-box .chg { font-size:12px; font-weight:600; display:block; margin-top:2px; }
    .chg-up { color:#00c896; }
    .chg-dn { color:#e94560; }
    .alert-box { background:rgba(233,69,96,0.08); border:1px solid rgba(233,69,96,0.25); border-radius:10px; padding:16px 20px; margin:16px 0; }
    .alert-box p { color:#e8e8f2; margin:0; }
    .success-box { background:rgba(0,200,150,0.07); border:1px solid rgba(0,200,150,0.2); border-radius:10px; padding:16px 20px; margin:16px 0; }
    .tag { display:inline-block; background:rgba(233,69,96,0.15); color:#e94560; font-size:11px; font-weight:700; letter-spacing:1px; text-transform:uppercase; padding:4px 10px; border-radius:20px; margin-bottom:16px; }
    @media(max-width:480px) {
      .body, .header, .footer { padding:20px; }
      .stat-row { flex-direction:column; }
    }
  </style>
</head>
<body>
<div class="wrapper">
  <div class="card">

    <!-- Header -->
    <div class="header">
      <a href="https://yousell.online" class="logo">
        <span class="logo-you">You</span><span class="logo-rest">Sell.Online</span>
      </a>
    </div>

    <!-- Body -->
    <div class="body">
      ${body_html}
      ${ctaText && ctaUrl ? `
      <div class="cta-wrap">
        <a href="${ctaUrl}" class="cta-btn">${ctaText}</a>
      </div>` : ''}
    </div>

    <hr class="divider">

    <!-- Footer -->
    <div class="footer">
      ${footer_note ? `<p>${footer_note}</p>` : ''}
      <p>© ${year} YouSell Online LLC · 254 Chapman Rd STE 208, Newark, DE 19702</p>
      <p>
        <a href="https://yousell.online/dashboard/">Dashboard</a> ·
        <a href="https://yousell.online/privacy-policy/">Privacy</a> ·
        <a href="https://yousell.online/terms-of-service/">Terms</a> ·
        <a href="{{unsubscribe_url}}">Unsubscribe</a>
      </p>
    </div>

  </div>
</div>
</body>
</html>`;
  }
};

// ══════════════════════════════════════════════════════════
// FALLBACK TEMPLATES
// Used when Claude API is unavailable
// ══════════════════════════════════════════════════════════
const Templates = {
  fallback(template, ctx) {
    const name = ctx.firstName || ctx.name || 'there';
    const map = {
      'account-created': {
        subject: `Welcome to YouSell, ${name} — let's build your store`,
        preview: 'Your dashboard is live. Here\'s what happens next.',
        body_html: `<p class="tag">Welcome</p><p>Hi ${name},</p><p>Your YouSell dashboard is live and your onboarding has begun. Our team will reach out within <strong>4 hours</strong> to kick off your store setup.</p><p><strong>Your first week with YouSell:</strong></p><ul><li>Account setup & platform connections configured</li><li>Product research and listing strategy prepared</li><li>PPC campaigns and creator outreach initiated</li></ul><p>Any questions in the meantime? Reply to this email or reach us at <a href="mailto:admin@yousell.online" style="color:#e94560">admin@yousell.online</a>.</p><p>— The YouSell Team</p>`
      },
      'platform-connected': {
        subject: `${ctx.platform} connected ✓ — data syncing now`,
        preview: `Your ${ctx.platform} store is now live in your dashboard.`,
        body_html: `<p class="tag">${ctx.platform} Connected</p><p>Hi ${name},</p><p>Your <strong>${ctx.platform}</strong> account is now connected to YouSell. Data will appear in your dashboard within <strong>30 minutes</strong>.</p><p>Our team will review your account data and be in touch within 4 hours with initial observations and next steps.</p>`
      },
      'first-sale': {
        subject: `🎉 First sale on ${ctx.platform}! — ${ctx.amount || 'order confirmed'}`,
        preview: 'The first one is always the sweetest. Here\'s what comes next.',
        body_html: `<div class="success-box"><p>🎉 <strong>First sale confirmed on ${ctx.platform}!</strong></p></div><p>Hi ${name},</p><p>Your first sale is in. This is a real milestone — you now have proof of concept, and the platform algorithm has started to notice your store.</p><p>The YouSell team is already working to capitalise on this momentum. Expect an update within 24 hours.</p>`
      },
      'weekly-report': {
        subject: `Week ${new Date().getWeek?.() || ''} report — ${ctx.totalRevenue || 'your performance summary'}`,
        preview: 'Your weekly numbers are in.',
        body_html: `<p class="tag">Weekly Report</p><p>Hi ${name},</p><p>Here's your performance summary for the week.</p>${ctx.amazon?.revenue ? `<div class="stat-row"><div class="stat-box"><span class="val">${ctx.amazon.revenue}</span><span class="lbl">Amazon</span><span class="chg ${ctx.amazon.change?.startsWith('+') ? 'chg-up':'chg-dn'}">${ctx.amazon.change||''}</span></div>${ctx.tiktok?.gmv?`<div class="stat-box"><span class="val">${ctx.tiktok.gmv}</span><span class="lbl">TikTok GMV</span><span class="chg ${ctx.tiktok.change?.startsWith('+')?'chg-up':'chg-dn'}">${ctx.tiktok.change||''}</span></div>`:''}${ctx.shopify?.revenue?`<div class="stat-box"><span class="val">${ctx.shopify.revenue}</span><span class="lbl">Shopify</span><span class="chg ${ctx.shopify.change?.startsWith('+')?'chg-up':'chg-dn'}">${ctx.shopify.change||''}</span></div>`:''}</div>`:''}<p>Full details are in your dashboard. The team will follow up with strategic recommendations for next week.</p>`
      },
      'milestone': {
        subject: `🏆 Milestone hit: ${ctx.milestone}`,
        preview: 'You\'ve reached a major milestone. Here\'s what it means.',
        body_html: `<div class="success-box"><p>🏆 <strong>${ctx.milestone}</strong> — achieved!</p></div><p>Hi ${name},</p><p>This is a real achievement. Most sellers never reach this point. The YouSell team will be in touch with your next growth targets.</p>`
      },
      'idle-warning': {
        subject: `${name}, your store has been active while you've been away`,
        preview: 'Log in to see what\'s happened in the last few days.',
        body_html: `<p>Hi ${name},</p><p>You haven't logged into your dashboard in <strong>${ctx.daysSinceLogin || 7} days</strong>. Your stores have been active — log in to review your latest performance data and any items needing attention.</p>`
      },
      'platform-issue': {
        subject: `⚠️ Action needed: ${ctx.issueType} on ${ctx.platform}`,
        preview: `Issue detected with your ${ctx.platform} account.`,
        body_html: `<div class="alert-box"><p>⚠️ <strong>${ctx.issueType}</strong> detected on your ${ctx.platform} account.</p></div><p>Hi ${name},</p><p>${ctx.action || 'Please log in to your dashboard to review and take action.'} Our team is monitoring the situation and will be in touch shortly.</p>`
      },
      'onboarding-step': {
        subject: `Step ${ctx.step} of 5: ${ctx.stepTitle}`,
        preview: `You're making great progress. Step ${ctx.step} is ready for you.`,
        body_html: `<p class="tag">Onboarding · Step ${ctx.step} of 5</p><p>Hi ${name},</p><p>You're making great progress. It's time for <strong>Step ${ctx.step}: ${ctx.stepTitle}</strong>.</p><p>${ctx.action}</p><p>This should take around <strong>${ctx.timeEstimate || '10 minutes'}</strong>. Why it matters: ${ctx.why}</p>`
      }
    };
    return map[template] || { subject: 'Update from YouSell', preview: 'News about your account.', body_html: `<p>Hi ${name},</p><p>Your YouSell team has an update for you. Log in to your dashboard for full details.</p>` };
  }
};

// ══════════════════════════════════════════════════════════
// EMAIL SENDER
// ══════════════════════════════════════════════════════════
const Mailer = {
  FROM: process.env.FROM_EMAIL || 'YouSell Team <hello@yousell.online>',
  REPLY_TO: 'admin@yousell.online',

  async send({ to, toName, template, context, ctaText, ctaUrl, footerNote, logToSupabase = true }) {
    const content = await AIWriter.writeEmail(template, { ...context, firstName: toName });
    const html = EmailRenderer.wrap(
      { ...content, ctaText, ctaUrl, footer_note: footerNote },
    );

    let sendResult;
    try {
      sendResult = await resend.emails.send({
        from:     this.FROM,
        reply_to: this.REPLY_TO,
        to:       [{ email: to, name: toName }],
        subject:  content.subject,
        html,
        headers: {
          'X-Entity-Ref-ID': `ys-${template}-${Date.now()}`
        }
      });
    } catch(e) {
      console.error('[Mailer] Send failed:', e.message);
      if (logToSupabase) {
        await this._logToSupabase({ to, toName, template, context, status: 'failed', error: e.message });
      }
      return { ok: false, error: e.message };
    }

    console.log(`[Mailer] ✓ Sent "${content.subject}" to ${to} (id: ${sendResult.id})`);

    if (logToSupabase) {
      await this._logToSupabase({ to, toName, template, context, status: 'sent', resend_id: sendResult.id, subject: content.subject });
    }

    return { ok: true, id: sendResult.id, subject: content.subject };
  },

  async _logToSupabase({ to, toName, template, context, status, resend_id, subject, error }) {
    try {
      await supabase.from('ys_email_log').insert({
        recipient_email: to,
        recipient_name:  toName,
        template,
        subject:         subject || null,
        context:         context || {},
        status,
        resend_id:       resend_id || null,
        error_message:   error || null,
        sent_at:         new Date().toISOString()
      });
    } catch(e) {
      console.warn('[Mailer] Supabase log failed:', e.message);
    }
  }
};

// ══════════════════════════════════════════════════════════
// ROUTE HANDLERS
// ══════════════════════════════════════════════════════════

function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

// 1. Account Created
app.post('/email/account-created', asyncHandler(async (req, res) => {
  const { email, name, service } = req.body;
  if (!email || !name) return res.status(400).json({ error: 'email and name required' });

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'account-created',
    context: { name, service: service || 'ecommerce services' },
    ctaText: 'Go to Your Dashboard →',
    ctaUrl: 'https://yousell.online/dashboard/',
    footerNote: "You're receiving this because you created a YouSell account."
  });

  // Trigger onboarding sequence step 1 after 30 minutes
  scheduleOnboarding(email, name, 1, 30 * 60 * 1000);

  res.json(result);
}));

// 2. Platform Connected
app.post('/email/platform-connected', asyncHandler(async (req, res) => {
  const { email, name, platform, storeName, connectedAt } = req.body;
  if (!email || !platform) return res.status(400).json({ error: 'email and platform required' });

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'platform-connected',
    context: { name, platform, storeName, connectedAt: connectedAt || new Date().toLocaleString() },
    ctaText: `View ${platform} Dashboard →`,
    ctaUrl: `https://yousell.online/dashboard/${platform.toLowerCase()}.html`,
    footerNote: `You're receiving this because you connected ${platform} to YouSell.`
  });

  res.json(result);
}));

// 3. First Sale
app.post('/email/first-sale', asyncHandler(async (req, res) => {
  const { email, name, platform, amount, product, saleTime } = req.body;
  if (!email || !platform) return res.status(400).json({ error: 'email and platform required' });

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'first-sale',
    context: { name, platform, amount, product, saleTime },
    ctaText: 'See Your Live Data →',
    ctaUrl: 'https://yousell.online/dashboard/',
    footerNote: "You're receiving this because you made your first sale through YouSell."
  });

  res.json(result);
}));

// 4. Weekly Report
app.post('/email/weekly-report', asyncHandler(async (req, res) => {
  const { email, name, amazon, tiktok, shopify, totalRevenue, topProduct, highlights } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'weekly-report',
    context: { name, amazon, tiktok, shopify, totalRevenue, topProduct, highlights },
    ctaText: 'View Full Dashboard →',
    ctaUrl: 'https://yousell.online/dashboard/',
    footerNote: "You're receiving this weekly report because you're a YouSell client."
  });

  res.json(result);
}));

// 5. Milestone Reached
app.post('/email/milestone', asyncHandler(async (req, res) => {
  const { email, name, milestone, platform, timeToMilestone, context: ctx } = req.body;
  if (!email || !milestone) return res.status(400).json({ error: 'email and milestone required' });

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'milestone',
    context: { name, milestone, platform, timeToMilestone, context: ctx },
    ctaText: 'See Your Progress →',
    ctaUrl: 'https://yousell.online/dashboard/',
    footerNote: "You're receiving this because you hit a milestone with YouSell."
  });

  res.json(result);
}));

// 6. Idle / Re-engagement Warning
app.post('/email/idle-warning', asyncHandler(async (req, res) => {
  const { email, name, daysSinceLogin, platforms, lastAction } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'idle-warning',
    context: { name, daysSinceLogin, platforms, lastAction },
    ctaText: 'Log In to Your Dashboard →',
    ctaUrl: 'https://yousell.online/dashboard/',
    footerNote: "You're receiving this because your YouSell dashboard has been inactive."
  });

  res.json(result);
}));

// 7. Platform Issue Alert
app.post('/email/platform-issue', asyncHandler(async (req, res) => {
  const { email, name, platform, issueType, severity, detectedAt, action } = req.body;
  if (!email || !platform || !issueType) return res.status(400).json({ error: 'email, platform, issueType required' });

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'platform-issue',
    context: { name, platform, issueType, severity, detectedAt, action },
    ctaText: 'Review Issue Now →',
    ctaUrl: `https://yousell.online/dashboard/${platform.toLowerCase()}.html`,
    footerNote: "You're receiving this alert because we monitor your connected platforms."
  });

  res.json(result);
}));

// 8. Onboarding Step
app.post('/email/onboarding/:step', asyncHandler(async (req, res) => {
  const step = parseInt(req.params.step);
  if (isNaN(step) || step < 1 || step > 5) return res.status(400).json({ error: 'step must be 1–5' });

  const { email, name } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });

  const steps = {
    1: { stepTitle: 'Connect Your First Platform',    action: 'Head to the Connections page in your dashboard and connect Amazon, TikTok Shop, or Shopify — whichever you\'re starting with.',  timeEstimate: '5 minutes',  why: 'Connecting your platform unlocks live data and lets our AI start analysing your store.' },
    2: { stepTitle: 'Review Your Store Audit',         action: 'Your YouSell team has completed an initial audit of your store. Log in to the Reports section to review their findings and recommendations.',       timeEstimate: '10 minutes', why: 'The audit identifies your biggest quick wins and the issues costing you revenue right now.' },
    3: { stepTitle: 'Approve Your First Strategy',     action: 'Your account manager has prepared a 90-day growth strategy. Review it in your dashboard and leave any feedback or approval.',                         timeEstimate: '15 minutes', why: 'Approving the strategy lets us move from planning to execution immediately.' },
    4: { stepTitle: 'Review First Week Performance',   action: 'Check your dashboard — your first week of data is in. Review the numbers and flag anything you want to discuss.',                                      timeEstimate: '10 minutes', why: 'Early data tells us what\'s working and what to optimise in week two.' },
    5: { stepTitle: 'Set Your 6-Month Revenue Target', action: 'Log in to your Settings page and update your revenue goals. This helps us calibrate every decision we make for your store.',                          timeEstimate: '5 minutes',  why: 'Having a clear target lets our AI optimise for your specific outcome, not a generic benchmark.' }
  };

  const stepData = steps[step];
  const completedSteps = step > 1 ? Array.from({length: step - 1}, (_, i) => steps[i + 1].stepTitle).join(', ') : 'Account created';

  const result = await Mailer.send({
    to: email, toName: name,
    template: 'onboarding-step',
    context: { name, step, ...stepData, completedSteps },
    ctaText: `Start Step ${step} →`,
    ctaUrl: 'https://yousell.online/dashboard/',
    footerNote: `This is step ${step} of your YouSell onboarding sequence.`
  });

  // Schedule next step if not the last
  if (step < 5) {
    const delays = { 1: 48, 2: 72, 3: 96, 4: 120 }; // hours between steps
    const delayMs = (delays[step] || 48) * 60 * 60 * 1000;
    scheduleOnboarding(email, name, step + 1, delayMs);
  }

  res.json(result);
}));

// ── Batch send endpoint (admin use) ──────────────────────
app.post('/email/batch', asyncHandler(async (req, res) => {
  const { recipients, template, context } = req.body;
  if (!Array.isArray(recipients) || !template) return res.status(400).json({ error: 'recipients array and template required' });
  if (recipients.length > 50) return res.status(400).json({ error: 'Max 50 recipients per batch' });

  const results = await Promise.allSettled(
    recipients.map(r => Mailer.send({
      to: r.email, toName: r.name,
      template, context: { ...context, name: r.name, ...r.context }
    }))
  );

  const summary = { sent: 0, failed: 0 };
  results.forEach(r => r.status === 'fulfilled' && r.value.ok ? summary.sent++ : summary.failed++);
  res.json(summary);
}));

// ── Email log endpoint (admin) ────────────────────────────
app.get('/email/log', asyncHandler(async (req, res) => {
  const { data, error } = await supabase
    .from('ys_email_log')
    .select('*')
    .order('sent_at', { ascending: false })
    .limit(100);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
}));

// ── Health check ──────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'yousell-email-service',
    timestamp: new Date().toISOString(),
    ai: !!process.env.ANTHROPIC_API_KEY ? 'configured' : 'missing',
    email: !!process.env.RESEND_API_KEY ? 'configured' : 'missing',
    supabase: !!process.env.SUPABASE_URL ? 'configured' : 'missing'
  });
});

// ══════════════════════════════════════════════════════════
// SCHEDULED ONBOARDING HELPER
// ══════════════════════════════════════════════════════════
const onboardingTimers = {};
function scheduleOnboarding(email, name, step, delayMs) {
  const key = `${email}-step${step}`;
  if (onboardingTimers[key]) return; // don't double-schedule
  console.log(`[Onboarding] Step ${step} for ${email} scheduled in ${Math.round(delayMs / 3600000)}h`);
  onboardingTimers[key] = setTimeout(async () => {
    try {
      const resp = await fetch(`http://localhost:${PORT}/email/onboarding/${step}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-email-service-token': process.env.EMAIL_SERVICE_SECRET },
        body: JSON.stringify({ email, name })
      });
      console.log(`[Onboarding] Step ${step} sent to ${email}:`, resp.status);
    } catch(e) {
      console.error(`[Onboarding] Step ${step} failed for ${email}:`, e.message);
    }
    delete onboardingTimers[key];
  }, delayMs);
}

// ══════════════════════════════════════════════════════════
// CRON JOBS
// ══════════════════════════════════════════════════════════

// Weekly reports — every Monday at 08:00
cron.schedule('0 8 * * 1', async () => {
  console.log('[Cron] Running weekly reports...');
  try {
    const { data: clients } = await supabase
      .from('ys_email_subscriptions')
      .select('email, name, weekly_report_enabled')
      .eq('weekly_report_enabled', true);

    for (const client of (clients || [])) {
      const metrics = await supabase
        .from('ys_metrics')
        .select('platform, metrics')
        .eq('user_id', client.user_id);

      const amazon  = metrics.data?.find(m => m.platform === 'amazon')?.metrics;
      const tiktok  = metrics.data?.find(m => m.platform === 'tiktok')?.metrics;
      const shopify = metrics.data?.find(m => m.platform === 'shopify')?.metrics;

      await Mailer.send({
        to: client.email, toName: client.name,
        template: 'weekly-report',
        context: { name: client.name, amazon, tiktok, shopify, totalRevenue: '$' + ((amazon?.revenue || 0) + (tiktok?.gmv || 0) + (shopify?.revenue || 0)).toLocaleString() },
        ctaText: 'View Full Dashboard →',
        ctaUrl: 'https://yousell.online/dashboard/'
      });
    }
    console.log(`[Cron] Weekly reports sent to ${(clients || []).length} clients.`);
  } catch(e) {
    console.error('[Cron] Weekly report job failed:', e.message);
  }
}, { timezone: 'America/New_York' });

// Re-engagement — check daily at 10:00, email users inactive 7+ days
cron.schedule('0 10 * * *', async () => {
  console.log('[Cron] Checking inactive users...');
  try {
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const { data: inactive } = await supabase
      .from('ys_email_subscriptions')
      .select('email, name, last_login_at, platforms')
      .lt('last_login_at', sevenDaysAgo)
      .eq('re_engagement_enabled', true)
      .is('re_engagement_sent_at', null);

    for (const user of (inactive || [])) {
      const daysSince = Math.floor((Date.now() - new Date(user.last_login_at).getTime()) / (24 * 60 * 60 * 1000));
      await Mailer.send({
        to: user.email, toName: user.name,
        template: 'idle-warning',
        context: { name: user.name, daysSinceLogin: daysSince, platforms: user.platforms },
        ctaText: 'Log In Now →',
        ctaUrl: 'https://yousell.online/dashboard/'
      });

      // Mark as sent so we don't spam
      await supabase.from('ys_email_subscriptions')
        .update({ re_engagement_sent_at: new Date().toISOString() })
        .eq('email', user.email);
    }
    console.log(`[Cron] Re-engagement emails sent to ${(inactive || []).length} users.`);
  } catch(e) {
    console.error('[Cron] Re-engagement job failed:', e.message);
  }
}, { timezone: 'America/New_York' });

// ── ERROR HANDLER ─────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('[Error]', err.message);
  res.status(500).json({ error: err.message || 'Internal error' });
});

// ── START ─────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅ YouSell Email Service running on http://localhost:${PORT}`);
  console.log(`   AI writer:  ${process.env.ANTHROPIC_API_KEY ? '✓ Claude configured' : '⚠ Missing ANTHROPIC_API_KEY'}`);
  console.log(`   Delivery:   ${process.env.RESEND_API_KEY    ? '✓ Resend configured'  : '⚠ Missing RESEND_API_KEY'}`);
  console.log(`   Database:   ${process.env.SUPABASE_URL       ? '✓ Supabase connected' : '⚠ Missing SUPABASE_URL'}`);
  console.log(`\n   Endpoints:`);
  console.log(`   POST /email/account-created`);
  console.log(`   POST /email/platform-connected`);
  console.log(`   POST /email/first-sale`);
  console.log(`   POST /email/weekly-report`);
  console.log(`   POST /email/milestone`);
  console.log(`   POST /email/idle-warning`);
  console.log(`   POST /email/platform-issue`);
  console.log(`   POST /email/onboarding/1..5`);
  console.log(`   GET  /health\n`);
});

module.exports = app;
