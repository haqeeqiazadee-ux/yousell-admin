-- ══════════════════════════════════════════════════════════
-- YouSell Email Automation — Supabase Schema
-- Run this in: supabase.com → your project → SQL Editor
-- ══════════════════════════════════════════════════════════

-- ── 1. Email Log ──────────────────────────────────────────
-- Records every email sent for auditing and analytics.

CREATE TABLE IF NOT EXISTS ys_email_log (
  id               uuid         DEFAULT gen_random_uuid() PRIMARY KEY,
  recipient_email  text         NOT NULL,
  recipient_name   text,
  template         text         NOT NULL,
  subject          text,
  context          jsonb        NOT NULL DEFAULT '{}',
  status           text         NOT NULL DEFAULT 'sent',  -- sent | failed | bounced
  resend_id        text,
  error_message    text,
  sent_at          timestamptz  DEFAULT now()
);

-- Index for fast lookups by recipient and template
CREATE INDEX IF NOT EXISTS idx_email_log_recipient ON ys_email_log(recipient_email);
CREATE INDEX IF NOT EXISTS idx_email_log_template  ON ys_email_log(template);
CREATE INDEX IF NOT EXISTS idx_email_log_sent_at   ON ys_email_log(sent_at DESC);

-- RLS: Only the service role can read/write email logs (server-side only)
ALTER TABLE ys_email_log ENABLE ROW LEVEL SECURITY;

-- Allow service role full access (used by email-service/server.js with service role key)
CREATE POLICY "Service role full access to email log"
  ON ys_email_log
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ── 2. Email Subscriptions ────────────────────────────────
-- Tracks each client's email preferences and engagement state.
-- One row per YouSell client.

CREATE TABLE IF NOT EXISTS ys_email_subscriptions (
  id                       uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id                  uuid        REFERENCES auth.users(id) ON DELETE CASCADE,
  email                    text        NOT NULL UNIQUE,
  name                     text,
  service                  text,        -- "Amazon Services" | "TikTok Shop" | "Shopify" | "AI Bundle"
  platforms                text[],      -- ['amazon','tiktok','shopify']

  -- Preferences
  weekly_report_enabled    boolean     DEFAULT true,
  milestone_emails_enabled boolean     DEFAULT true,
  issue_alerts_enabled     boolean     DEFAULT true,
  re_engagement_enabled    boolean     DEFAULT true,

  -- State tracking
  onboarding_step          integer     DEFAULT 0,
  last_login_at            timestamptz DEFAULT now(),
  re_engagement_sent_at    timestamptz,

  -- Metadata
  created_at               timestamptz DEFAULT now(),
  updated_at               timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_subs_user_id       ON ys_email_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subs_email         ON ys_email_subscriptions(email);
CREATE INDEX IF NOT EXISTS idx_subs_last_login    ON ys_email_subscriptions(last_login_at);

ALTER TABLE ys_email_subscriptions ENABLE ROW LEVEL SECURITY;

-- Users can read and update their own subscription preferences
CREATE POLICY "Users manage own subscription"
  ON ys_email_subscriptions
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Service role can access all (for cron jobs)
CREATE POLICY "Service role full access to subscriptions"
  ON ys_email_subscriptions
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ── 3. Auto-update last_login_at via trigger ──────────────
-- Called when dashboard.js updates the session

CREATE OR REPLACE FUNCTION ys_update_last_login()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ys_subs_updated_at
  BEFORE UPDATE ON ys_email_subscriptions
  FOR EACH ROW EXECUTE FUNCTION ys_update_last_login();

-- ── 4. Helper view: Email analytics ──────────────────────
-- Useful for reviewing email performance in Supabase dashboard

CREATE OR REPLACE VIEW ys_email_analytics AS
SELECT
  template,
  COUNT(*)                                                           AS total_sent,
  COUNT(*) FILTER (WHERE status = 'sent')                           AS delivered,
  COUNT(*) FILTER (WHERE status = 'failed')                         AS failed,
  ROUND(COUNT(*) FILTER (WHERE status = 'sent')::numeric / NULLIF(COUNT(*),0) * 100, 1) AS delivery_rate_pct,
  MIN(sent_at)                                                       AS first_sent,
  MAX(sent_at)                                                       AS last_sent
FROM ys_email_log
GROUP BY template
ORDER BY total_sent DESC;

-- ══════════════════════════════════════════════════════════
-- USAGE NOTES
-- ══════════════════════════════════════════════════════════
--
-- After running this schema:
--
-- 1. The email service (server.js) uses SUPABASE_SERVICE_ROLE_KEY
--    to write to ys_email_log and read from ys_email_subscriptions.
--
-- 2. dashboard.js uses SUPABASE_ANON_KEY and only accesses
--    ys_email_subscriptions for the currently logged-in user
--    (protected by RLS).
--
-- 3. To view all sent emails:
--    SELECT * FROM ys_email_log ORDER BY sent_at DESC;
--
-- 4. To view delivery analytics:
--    SELECT * FROM ys_email_analytics;
--
-- 5. To check a specific client's email history:
--    SELECT template, subject, status, sent_at
--    FROM ys_email_log
--    WHERE recipient_email = 'client@example.com'
--    ORDER BY sent_at DESC;
