/**
 * YouSell Dashboard — Proxy Server
 * ------------------------------------
 * Handles CORS and API credential security for:
 *   • Amazon SP-API (LWA OAuth + REST)
 *   • TikTok Shop Open API
 *   • Shopify Admin API
 *
 * Usage:
 *   npm install express cors axios dotenv
 *   node proxy-server.js
 *
 * Then update API base URL in dashboard.js from
 * client-side fetch to: http://localhost:3001/api/...
 */

require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const axios     = require('axios');
const helmet    = require('helmet');
const rateLimit = require('express-rate-limit');

const app  = express();
const PORT = process.env.PORT || 3001;

// ── SECURITY MIDDLEWARE ──────────────────────────────────

// 1. Helmet — sets security headers automatically
app.use(helmet({ contentSecurityPolicy: false }));

// 2. CORS — restrict to production domain
app.use(cors({
  origin: process.env.ALLOWED_ORIGIN || 'https://yousell.online',
  methods: ['GET','POST','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization']
}));

// 3. JSON body limit — prevent large payload attacks
app.use(express.json({ limit: '10kb' }));

// 4. Request logging
app.use((req, _res, next) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
  console.log('[' + new Date().toISOString() + '] ' + req.method + ' ' + req.path + ' - IP: ' + ip);
  _res.on('finish', () => console.log('[' + new Date().toISOString() + '] ' + req.method + ' ' + req.path + ' ' + _res.statusCode + ' - IP: ' + ip));
  next();
});

// 5. General rate limiter — 100 requests per 15 minutes per IP
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 100, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.', status: 429 }
});

// 6. Strict limiter for auth token endpoints — 10 per minute
const authLimiter = rateLimit({
  windowMs: 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many token requests. Please wait before retrying.', status: 429 }
});

app.use('/api/', generalLimiter);

// 7. Input sanitiser — strips HTML, enforces max lengths
function sanitiseBody(obj) {
  const clean = {};
  for (const [k, v] of Object.entries(obj || {})) {
    clean[k] = typeof v === 'string' ? v.replace(/<[^>]*>/g, '').trim() : v;
  }
  return clean;
}

function validateRequired(...fields) {
  return (req, res, next) => {
    req.body = sanitiseBody(req.body);
    const missing = fields.filter(f => !req.body[f] || typeof req.body[f] !== 'string');
    if (missing.length > 0) return res.status(400).json({ error: 'Missing required fields: ' + missing.join(', ') });
    for (const [k, v] of Object.entries(req.body)) {
      const maxLen = ['shopDomain'].includes(k) ? 100 : 500;
      if (typeof v === 'string' && v.length > maxLen) return res.status(400).json({ error: 'Field '' + k + '' exceeds maximum length.' });
    }
    next();
  };
}

// ── HELPERS ──────────────────────────────────────────────
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

// ── AMAZON SP-API ────────────────────────────────────────

/**
 * POST /api/amazon/token
 * Exchange or refresh an Amazon LWA access token.
 * Body: { clientId, clientSecret, refreshToken }
 */
app.post('/api/amazon/token', authLimiter, validateRequired('clientId','clientSecret','refreshToken'), asyncHandler(async (req, res) => {
  const { clientId, clientSecret, refreshToken } = req.body;
  if (!clientId || !clientSecret || !refreshToken) {
    return res.status(400).json({ error: 'Missing credentials' });
  }
  const response = await axios.post('https://api.amazon.com/auth/o2/token', new URLSearchParams({
    grant_type:    'refresh_token',
    refresh_token: refreshToken,
    client_id:     clientId,
    client_secret: clientSecret,
  }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });

  res.json({ accessToken: response.data.access_token, expiresIn: response.data.expires_in });
}));

/**
 * POST /api/amazon/orders
 * Fetch recent orders from SP-API.
 * Body: { accessToken, marketplaceId?, createdAfter? }
 */
app.post('/api/amazon/orders', asyncHandler(async (req, res) => {
  const { accessToken, marketplaceId = 'ATVPDKIKX0DER', createdAfter } = req.body;
  const after = createdAfter || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

  const response = await axios.get('https://sellingpartnerapi-na.amazon.com/orders/v0/orders', {
    params: { MarketplaceIds: marketplaceId, CreatedAfter: after, OrderStatuses: 'Shipped,Unshipped,Pending' },
    headers: { 'x-amz-access-token': accessToken, 'content-type': 'application/json' }
  });
  res.json(response.data);
}));

/**
 * POST /api/amazon/finances
 * Fetch financial events (revenue, fees, refunds).
 * Body: { accessToken, postedAfter? }
 */
app.post('/api/amazon/finances', asyncHandler(async (req, res) => {
  const { accessToken, postedAfter } = req.body;
  const after = postedAfter || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

  const response = await axios.get('https://sellingpartnerapi-na.amazon.com/finances/v0/financialEvents', {
    params: { PostedAfter: after },
    headers: { 'x-amz-access-token': accessToken }
  });
  res.json(response.data);
}));

/**
 * POST /api/amazon/catalog
 * Fetch catalog items.
 * Body: { accessToken, asins? }
 */
app.post('/api/amazon/catalog', asyncHandler(async (req, res) => {
  const { accessToken, asins = [], marketplaceId = 'ATVPDKIKX0DER' } = req.body;
  const response = await axios.get('https://sellingpartnerapi-na.amazon.com/catalog/2022-04-01/items', {
    params: { identifiers: asins.join(','), identifiersType: 'ASIN', marketplaceIds: marketplaceId },
    headers: { 'x-amz-access-token': accessToken }
  });
  res.json(response.data);
}));

/**
 * POST /api/amazon/report
 * Request and poll a sales report.
 * Body: { accessToken, reportType?, startDate?, endDate? }
 */
app.post('/api/amazon/report', asyncHandler(async (req, res) => {
  const { accessToken, reportType = 'GET_FLAT_FILE_ALL_ORDERS_DATA_BY_ORDER_DATE_GENERAL', startDate, endDate } = req.body;

  // Create report
  const createRes = await axios.post('https://sellingpartnerapi-na.amazon.com/reports/2021-06-30/reports', {
    reportType,
    dataStartTime: startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    dataEndTime: endDate || new Date().toISOString(),
    marketplaceIds: ['ATVPDKIKX0DER']
  }, { headers: { 'x-amz-access-token': accessToken, 'content-type': 'application/json' } });

  res.json({ reportId: createRes.data.reportId, status: 'REQUESTED' });
}));

// ── TIKTOK SHOP OPEN API ─────────────────────────────────

/**
 * POST /api/tiktok/token
 * Exchange auth code for access token.
 * Body: { appKey, appSecret, authCode }
 */
app.post('/api/tiktok/token', authLimiter, validateRequired('appKey','appSecret','authCode'), asyncHandler(async (req, res) => {
  const { appKey, appSecret, authCode } = req.body;
  const response = await axios.get('https://auth.tiktok-shops.com/api/v2/token/get', {
    params: { app_key: appKey, app_secret: appSecret, auth_code: authCode, grant_type: 'authorized_code' }
  });
  res.json(response.data);
}));

/**
 * POST /api/tiktok/refresh-token
 * Refresh an expired TikTok access token (expires every 24h).
 * Body: { appKey, appSecret, refreshToken }
 */
app.post('/api/tiktok/refresh-token', authLimiter, validateRequired('appKey','appSecret','refreshToken'), asyncHandler(async (req, res) => {
  const { appKey, appSecret, refreshToken } = req.body;
  const response = await axios.get('https://auth.tiktok-shops.com/api/v2/token/refresh', {
    params: { app_key: appKey, app_secret: appSecret, refresh_token: refreshToken, grant_type: 'refresh_token' }
  });
  res.json(response.data);
}));

/**
 * POST /api/tiktok/orders
 * Fetch TikTok Shop orders.
 * Body: { accessToken, shopId, createTimeStart?, createTimeEnd? }
 */
app.post('/api/tiktok/orders', asyncHandler(async (req, res) => {
  const { accessToken, shopId, createTimeStart, createTimeEnd } = req.body;
  const start = createTimeStart || Math.floor(Date.now()/1000 - 30 * 24 * 60 * 60);
  const end   = createTimeEnd   || Math.floor(Date.now()/1000);

  // Build TikTok request signature (simplified — implement full HMAC-SHA256 in production)
  const response = await axios.get('https://open-api.tiktokglobalshop.com/api/orders/search', {
    params: {
      app_key: process.env.TIKTOK_APP_KEY,
      access_token: accessToken,
      shop_id: shopId,
      create_time_ge: start,
      create_time_le: end,
      page_size: 100,
    },
    headers: { 'x-tts-access-token': accessToken }
  });
  res.json(response.data);
}));

/**
 * POST /api/tiktok/products
 * Fetch product list.
 * Body: { accessToken, shopId }
 */
app.post('/api/tiktok/products', asyncHandler(async (req, res) => {
  const { accessToken, shopId } = req.body;
  const response = await axios.get('https://open-api.tiktokglobalshop.com/api/products/search', {
    params: { app_key: process.env.TIKTOK_APP_KEY, access_token: accessToken, shop_id: shopId, page_size: 50 },
    headers: { 'x-tts-access-token': accessToken }
  });
  res.json(response.data);
}));

/**
 * POST /api/tiktok/creators
 * Fetch active affiliate creators.
 * Body: { accessToken, shopId }
 */
app.post('/api/tiktok/creators', asyncHandler(async (req, res) => {
  const { accessToken, shopId } = req.body;
  const response = await axios.get('https://open-api.tiktokglobalshop.com/api/affiliate/creator_list', {
    params: { app_key: process.env.TIKTOK_APP_KEY, access_token: accessToken, shop_id: shopId, page_size: 50 },
    headers: { 'x-tts-access-token': accessToken }
  });
  res.json(response.data);
}));

// ── SHOPIFY ADMIN API ────────────────────────────────────

/**
 * POST /api/shopify/orders
 * Fetch orders from Shopify store.
 * Body: { shopDomain, accessToken, apiVersion?, createdAtMin? }
 */
app.post('/api/shopify/orders', asyncHandler(async (req, res) => {
  const { shopDomain, accessToken, apiVersion = '2024-01', createdAtMin } = req.body;
  const since = createdAtMin || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
  const domain = shopDomain.replace(/^https?:\/\//, '');

  const response = await axios.get(`https://${domain}/admin/api/${apiVersion}/orders.json`, {
    params: { status: 'any', limit: 250, created_at_min: since },
    headers: { 'X-Shopify-Access-Token': accessToken, 'Content-Type': 'application/json' }
  });
  res.json(response.data);
}));

/**
 * POST /api/shopify/products
 * Fetch products.
 * Body: { shopDomain, accessToken, apiVersion? }
 */
app.post('/api/shopify/products', asyncHandler(async (req, res) => {
  const { shopDomain, accessToken, apiVersion = '2024-01' } = req.body;
  const domain = shopDomain.replace(/^https?:\/\//, '');
  const response = await axios.get(`https://${domain}/admin/api/${apiVersion}/products.json`, {
    params: { limit: 250, fields: 'id,title,variants,images' },
    headers: { 'X-Shopify-Access-Token': accessToken }
  });
  res.json(response.data);
}));

/**
 * POST /api/shopify/customers-count
 * Get total customer (email subscriber) count.
 * Body: { shopDomain, accessToken, apiVersion? }
 */
app.post('/api/shopify/customers-count', asyncHandler(async (req, res) => {
  const { shopDomain, accessToken, apiVersion = '2024-01' } = req.body;
  const domain = shopDomain.replace(/^https?:\/\//, '');
  const response = await axios.get(`https://${domain}/admin/api/${apiVersion}/customers/count.json`, {
    headers: { 'X-Shopify-Access-Token': accessToken }
  });
  res.json(response.data);
}));

/**
 * POST /api/shopify/analytics
 * Fetch basic analytics.
 * Body: { shopDomain, accessToken, apiVersion? }
 */
app.post('/api/shopify/analytics', asyncHandler(async (req, res) => {
  const { shopDomain, accessToken, apiVersion = '2024-01' } = req.body;
  const domain = shopDomain.replace(/^https?:\/\//, '');
  // Fetch sessions and conversion data
  const [ordersRes, customersRes] = await Promise.all([
    axios.get(`https://${domain}/admin/api/${apiVersion}/orders/count.json`, {
      params: { status: 'any', created_at_min: new Date(Date.now()-30*24*60*60*1000).toISOString() },
      headers: { 'X-Shopify-Access-Token': accessToken }
    }),
    axios.get(`https://${domain}/admin/api/${apiVersion}/customers/count.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken }
    })
  ]);
  res.json({ orderCount: ordersRes.data.count, customerCount: customersRes.data.count });
}));

// ── HEALTH CHECK ─────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    services: { amazon: 'ready', tiktok: 'ready', shopify: 'ready' }
  });
});

// ── ERROR HANDLER ────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error('[Proxy Error]', err.message);
  const status  = err.response?.status  || 500;
  const message = err.response?.data?.message || err.message || 'Internal proxy error';
  res.status(status).json({ error: message, status });
});

// ── START ────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅ YouSell Proxy Server running on http://localhost:${PORT}`);
  console.log(`   Amazon  → POST /api/amazon/orders  (+ /token, /finances, /catalog, /report)`);
  console.log(`   TikTok  → POST /api/tiktok/orders  (+ /token, /refresh-token, /products, /creators)`);
  console.log(`   Shopify → POST /api/shopify/orders (+ /products, /customers-count, /analytics)`);
  console.log(`   Health  → GET  /api/health\n`);
});

module.exports = app;
