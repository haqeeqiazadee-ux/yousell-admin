/* YouSell Dashboard — Core JS with Supabase Integration */

// ══════════════════════════════════════════════════════════
// SUPABASE CONFIG
// Replace these two values with your real credentials.
// Find them at: supabase.com → your project → Settings → API
// ══════════════════════════════════════════════════════════
const SUPABASE_URL      = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

// Detect whether Supabase has been configured
const SUPABASE_CONFIGURED = (
  SUPABASE_URL      !== 'YOUR_SUPABASE_URL' &&
  SUPABASE_ANON_KEY !== 'YOUR_SUPABASE_ANON_KEY' &&
  SUPABASE_URL.startsWith('https://')
);

// Lazy-load the Supabase JS client from CDN (only when configured)
let _supabase = null;
async function getSupabase() {
  if (!SUPABASE_CONFIGURED) return null;
  if (_supabase) return _supabase;
  if (!window.supabase) {
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js';
      s.onload = resolve; s.onerror = reject;
      document.head.appendChild(s);
    });
  }
  _supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true }
  });
  return _supabase;
}

// ── AUTH ─────────────────────────────────────────────────
// Supabase when configured, localStorage demo fallback otherwise.
const Auth = {
  DEMO: { email: 'demo@yousell.online', password: 'YouSell2025', name: 'Demo Client', initials: 'DC' },

  async check() {
    if (SUPABASE_CONFIGURED) {
      try {
        const sb = await getSupabase();
        const { data: { session } } = await sb.auth.getSession();
        if (!session) return null;
        const meta = session.user.user_metadata || {};
        const name = meta.full_name || session.user.email;
        const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
        return { email: session.user.email, name, initials, isDemo: false, supabaseSession: session };
      } catch(e) {
        console.warn('[Auth] Supabase check failed, falling back to local:', e.message);
        return this._checkLocal();
      }
    }
    return this._checkLocal();
  },

  _checkLocal() {
    const s = localStorage.getItem('ys_session');
    if (!s) return null;
    try {
      const session = JSON.parse(s);
      if (Date.now() > session.expires) { this._clearLocal(); return null; }
      return session;
    } catch(e) { this._clearLocal(); return null; }
  },

  _clearLocal() { localStorage.removeItem('ys_session'); },

  async login(email, password, remember) {
    const isDemo = email === this.DEMO.email && password === this.DEMO.password;
    if (isDemo) {
      const session = {
        email, name: this.DEMO.name, initials: 'DC', isDemo: true,
        expires: Date.now() + (remember ? 7*24*60*60*1000 : 24*60*60*1000)
      };
      localStorage.setItem('ys_session', JSON.stringify(session));
      return { ok: true };
    }
    if (SUPABASE_CONFIGURED) {
      try {
        const sb = await getSupabase();
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) return { ok: false, message: error.message };
        return { ok: true };
      } catch(e) { return { ok: false, message: 'Connection error. Please try again.' }; }
    }
    // Local fallback
    const users = JSON.parse(localStorage.getItem('ys_users') || '[]');
    const user = users.find(u => u.email === email && u.password === btoa(password));
    if (!user) return { ok: false, message: 'Invalid email or password.' };
    const name = user.name;
    const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    const session = { email, name, initials, isDemo: false, expires: Date.now() + (remember ? 7*24*60*60*1000 : 24*60*60*1000) };
    localStorage.setItem('ys_session', JSON.stringify(session));
    return { ok: true };
  },

  async signup(email, password, fullName) {
    if (SUPABASE_CONFIGURED) {
      try {
        const sb = await getSupabase();
        const { data, error } = await sb.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
        if (error) return { ok: false, message: error.message };
        return { ok: true, needsConfirmation: !data.session };
      } catch(e) { return { ok: false, message: 'Signup failed. Please try again.' }; }
    }
    const users = JSON.parse(localStorage.getItem('ys_users') || '[]');
    if (users.find(u => u.email === email)) return { ok: false, message: 'Email already registered.' };
    users.push({ email, password: btoa(password), name: fullName });
    localStorage.setItem('ys_users', JSON.stringify(users));
    return { ok: true };
  },

  async resetPassword(email) {
    if (SUPABASE_CONFIGURED) {
      try {
        const sb = await getSupabase();
        const { error } = await sb.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin + '/dashboard/login.html?reset=true'
        });
        if (error) return { ok: false, message: error.message };
        return { ok: true };
      } catch(e) { return { ok: false, message: 'Reset request failed.' }; }
    }
    return { ok: false, message: 'Password reset requires Supabase to be configured.' };
  },

  async logout() {
    if (SUPABASE_CONFIGURED) {
      try { const sb = await getSupabase(); await sb.auth.signOut(); } catch(e) {}
    }
    this._clearLocal();
    window.location.href = 'login.html';
  },

  async require() {
    const s = await this.check();
    if (!s) { window.location.href = 'login.html'; return null; }
    return s;
  }
};

// ── PLATFORM CONNECTIONS ─────────────────────────────────
// Stored in Supabase ys_connections table when configured,
// localStorage otherwise.
const Connections = {
  _table: 'ys_connections',

  async get() {
    if (SUPABASE_CONFIGURED) {
      try {
        const sb = await getSupabase();
        const { data: { user } } = await sb.auth.getUser();
        if (!user) return this._getLocal();
        const { data, error } = await sb.from(this._table)
          .select('platform, credentials, connected_at')
          .eq('user_id', user.id);
        if (error) { console.warn('[Connections] Read error:', error.message); return this._getLocal(); }
        const result = {};
        (data || []).forEach(row => { result[row.platform] = { ...row.credentials, connectedAt: row.connected_at }; });
        return result;
      } catch(e) { return this._getLocal(); }
    }
    return this._getLocal();
  },

  async set(platform, credentialData) {
    if (SUPABASE_CONFIGURED) {
      try {
        const sb = await getSupabase();
        const { data: { user } } = await sb.auth.getUser();
        if (user) {
          const { error } = await sb.from(this._table).upsert({
            user_id: user.id, platform: platform.toLowerCase(),
            credentials: credentialData, connected_at: new Date().toISOString()
          }, { onConflict: 'user_id,platform' });
          if (!error) { Cache.clear(); return; }
          console.warn('[Connections] Write error:', error.message);
        }
      } catch(e) {}
    }
    const c = this._getLocal();
    c[platform] = { ...credentialData, connectedAt: Date.now() };
    localStorage.setItem('ys_connections', JSON.stringify(c));
    Cache.clear();
  },

  async remove(platform) {
    if (SUPABASE_CONFIGURED) {
      try {
        const sb = await getSupabase();
        const { data: { user } } = await sb.auth.getUser();
        if (user) {
          await sb.from(this._table).delete().eq('user_id', user.id).eq('platform', platform.toLowerCase());
          Cache.clear(); return;
        }
      } catch(e) {}
    }
    const c = this._getLocal();
    delete c[platform];
    localStorage.setItem('ys_connections', JSON.stringify(c));
    Cache.clear();
  },

  async isConnected(platform) { const all = await this.get(); return !!all[platform.toLowerCase()]; },
  async getAll() { return this.get(); },
  _getLocal() { try { return JSON.parse(localStorage.getItem('ys_connections') || '{}'); } catch(e) { return {}; } }
};

// ── CACHE ────────────────────────────────────────────────
const Cache = {
  TTL: 15 * 60 * 1000,
  _mem: {},
  set(key, data) {
    const entry = { data, ts: Date.now() };
    this._mem[key] = entry;
    try { localStorage.setItem('ys_cache_' + key, JSON.stringify(entry)); } catch(e) {}
  },
  get(key) {
    const mem = this._mem[key];
    if (mem && Date.now() - mem.ts < this.TTL) return mem.data;
    try {
      const raw = localStorage.getItem('ys_cache_' + key);
      if (!raw) return null;
      const c = JSON.parse(raw);
      if (Date.now() - c.ts > this.TTL) { localStorage.removeItem('ys_cache_' + key); return null; }
      this._mem[key] = c; return c.data;
    } catch(e) { return null; }
  },
  clear() {
    this._mem = {};
    Object.keys(localStorage).filter(k => k.startsWith('ys_cache_')).forEach(k => localStorage.removeItem(k));
  }
};

// ── CLOUD DATA ───────────────────────────────────────────
// Saves/loads platform metrics to Supabase ys_metrics table.
const CloudData = {
  _table: 'ys_metrics',
  async save(platform, metrics) {
    if (!SUPABASE_CONFIGURED) return;
    try {
      const sb = await getSupabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      await sb.from(this._table).upsert({
        user_id: user.id, platform: platform.toLowerCase(),
        metrics, updated_at: new Date().toISOString()
      }, { onConflict: 'user_id,platform' });
    } catch(e) { console.warn('[CloudData] Save failed:', e.message); }
  },
  async load(platform) {
    if (!SUPABASE_CONFIGURED) return null;
    try {
      const sb = await getSupabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return null;
      const { data, error } = await sb.from(this._table).select('metrics').eq('user_id', user.id).eq('platform', platform.toLowerCase()).single();
      if (error || !data) return null;
      return data.metrics;
    } catch(e) { return null; }
  },
  async loadAll() {
    if (!SUPABASE_CONFIGURED) return {};
    try {
      const sb = await getSupabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return {};
      const { data, error } = await sb.from(this._table).select('platform, metrics').eq('user_id', user.id);
      if (error || !data) return {};
      const result = {};
      data.forEach(row => { result[row.platform] = row.metrics; });
      return result;
    } catch(e) { return {}; }
  }
};

// ── MOCK DATA ────────────────────────────────────────────
const Mock = {
  revenue30days() {
    const days = []; const now = new Date();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now); d.setDate(d.getDate() - i);
      const label = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      days.push({ label, amazon: Math.floor(800 + Math.random()*1200 + (29-i)*30), tiktok: Math.floor(400 + Math.random()*800 + (29-i)*20), shopify: Math.floor(300 + Math.random()*600 + (29-i)*15) });
    }
    return days;
  },
  amazonData: {
    revenue: 41280, orders: 342, units: 489, acos: 18.4, ppcSpend: 2140, ppcRevenue: 11630,
    health: 'Good', bsr: [
      { asin: 'B09XK2L4M1', title: 'Kitchen Organiser Set', bsr: 1842, units: 124, revenue: 11160 },
      { asin: 'B09XK2L4M2', title: 'Bamboo Cutting Board',  bsr: 3291, units: 98,  revenue: 8820  },
      { asin: 'B09XK2L4M3', title: 'Spice Rack Wall Mount', bsr: 4102, units: 87,  revenue: 6960  },
      { asin: 'B09XK2L4M4', title: 'Pot Lid Holder',        bsr: 6844, units: 72,  revenue: 5040  },
      { asin: 'B09XK2L4M5', title: 'Kitchen Utensil Set',   bsr: 8291, units: 61,  revenue: 4880  }
    ]
  },
  tiktokData: {
    gmv: 28400, orders: 891, creators: 47, commissionPaid: 2840, convRate: 3.2, health: 'Good',
    topVideos: [
      { creator: '@fashionwithpriya',  views: '2.4M', gmv: 4200, conv: '4.1%', status: 'active' },
      { creator: '@beautyreviews_usa', views: '1.8M', gmv: 3100, conv: '3.8%', status: 'active' },
      { creator: '@homeaesthetics',    views: '1.2M', gmv: 2400, conv: '3.2%', status: 'active' },
      { creator: '@shopwithme_nyc',    views: '890K', gmv: 1900, conv: '2.9%', status: 'active' },
      { creator: '@trendsetter_la',    views: '720K', gmv: 1600, conv: '2.6%', status: 'paused'  }
    ]
  },
  shopifyData: {
    revenue: 14200, orders: 258, aov: 55, convRate: 2.8, emailSubs: 1104,
    traffic: { google: 42, direct: 28, social: 18, email: 12 },
    topProducts: [
      { name: 'Premium Leather Wallet', orders: 84, revenue: 5040, stock: 142 },
      { name: 'Canvas Tote Bag',        orders: 67, revenue: 2680, stock: 89  },
      { name: 'Silver Chain Bracelet',  orders: 52, revenue: 2080, stock: 203 },
      { name: 'Minimalist Watch',       orders: 31, revenue: 3100, stock: 45  },
      { name: 'Sunglasses - Classic',   orders: 24, revenue: 1200, stock: 67  }
    ]
  },
  activity: [
    { icon: '📦', bg: 'rgba(255,153,0,0.1)',  title: 'New Amazon order — B09XK2L4M1',     sub: '2 units · $89.90',                          time: '2 min ago'  },
    { icon: '🎵', bg: 'rgba(255,0,80,0.08)',  title: 'TikTok creator posted new video',    sub: '@fashionwithpriya · 12K views in 1hr',      time: '14 min ago' },
    { icon: '🛍️', bg: 'rgba(0,200,100,0.08)', title: 'Shopify order #1847',               sub: 'Premium Leather Wallet · $60',              time: '28 min ago' },
    { icon: '🤖', bg: 'rgba(233,69,96,0.08)', title: 'AI repricing triggered on 3 ASINs', sub: 'Buy Box won on B09XK2L4M1, M2, M4',         time: '1 hr ago'   },
    { icon: '⭐', bg: 'rgba(245,158,11,0.1)', title: 'New 5-star review received',         sub: 'Kitchen Organiser Set · "Absolutely love it!"', time: '2 hr ago' },
    { icon: '📈', bg: 'rgba(59,130,246,0.1)', title: 'Weekly report generated',            sub: 'Amazon · TikTok · Shopify — Week 12',       time: '3 hr ago'   }
  ]
};

// ── AMAZON SP-API ─────────────────────────────────────────
const AmazonAPI = {
  PROXY: '/api/proxy',
  async getOrders(creds) {
    const cached = Cache.get('amz_orders');
    if (cached) return cached;
    try {
      const token = await this.refreshToken(creds);
      const r = await fetch(`${this.PROXY}/amazon/orders`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token, endpoint: '/orders/v0/orders', params: { MarketplaceIds: 'ATVPDKIKX0DER', CreatedAfter: new Date(Date.now()-30*24*60*60*1000).toISOString() } }) });
      const data = await r.json(); Cache.set('amz_orders', data); return data;
    } catch(e) { console.warn('[AmazonAPI] Unavailable, using mock data'); return Mock.amazonData; }
  },
  async refreshToken(creds) {
    const r = await fetch('https://api.amazon.com/auth/o2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: creds.refreshToken, client_id: creds.clientId, client_secret: creds.clientSecret }) });
    return (await r.json()).access_token;
  }
};

const TikTokAPI = {
  async getOrders(creds) {
    const cached = Cache.get('ttk_orders');
    if (cached) return cached;
    try {
      const r = await fetch('/api/proxy/tiktok/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ access_token: creds.accessToken, shop_id: creds.shopId }) });
      const data = await r.json(); Cache.set('ttk_orders', data); return data;
    } catch(e) { console.warn('[TikTokAPI] Unavailable, using mock data'); return Mock.tiktokData; }
  }
};

const ShopifyAPI = {
  async getOrders(creds) {
    const cached = Cache.get('shp_orders');
    if (cached) return cached;
    try {
      const r = await fetch('/api/proxy/shopify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: `https://${creds.shopDomain}/admin/api/2024-01/orders.json?status=any&limit=250&created_at_min=${new Date(Date.now()-30*24*60*60*1000).toISOString()}`, token: creds.accessToken }) });
      const data = await r.json(); Cache.set('shp_orders', data); return data;
    } catch(e) { console.warn('[ShopifyAPI] Unavailable, using mock data'); return Mock.shopifyData; }
  }
};

// ── UI HELPERS ────────────────────────────────────────────
const UI = {
  sidebar: null,
  init() {
    this.sidebar = document.getElementById('sidebar');
    this.initSidebar();
    this.initNotifications();
    this.applySession();
    this.initMobile();
    document.querySelectorAll('[data-modal-open]').forEach(btn => btn.addEventListener('click', () => this.openModal(btn.dataset.modalOpen)));
    document.querySelectorAll('[data-modal-close]').forEach(btn => btn.addEventListener('click', () => this.closeModal(btn.closest('.modal-backdrop').id)));
    document.querySelectorAll('.modal-backdrop').forEach(m => m.addEventListener('click', e => { if (e.target === m) this.closeModal(m.id); }));
  },
  initSidebar() {
    const collapsed = localStorage.getItem('ys_sidebar') === '1';
    if (collapsed && this.sidebar) { this.sidebar.classList.add('collapsed'); document.querySelector('.main')?.classList.add('expanded'); }
    document.getElementById('sidebar-toggle')?.addEventListener('click', () => {
      const c = this.sidebar.classList.toggle('collapsed');
      document.querySelector('.main')?.classList.toggle('expanded', c);
      localStorage.setItem('ys_sidebar', c ? '1' : '0');
    });
  },
  initMobile() {
    const overlay = document.getElementById('mobile-overlay');
    document.getElementById('mobile-menu-btn')?.addEventListener('click', () => { this.sidebar?.classList.add('mobile-open'); overlay?.classList.add('show'); });
    overlay?.addEventListener('click', () => { this.sidebar?.classList.remove('mobile-open'); overlay.classList.remove('show'); });
  },
  initNotifications() {
    const btn = document.getElementById('notif-btn');
    const dropdown = document.getElementById('notif-dropdown');
    btn?.addEventListener('click', e => { e.stopPropagation(); dropdown?.classList.toggle('open'); });
    document.addEventListener('click', () => dropdown?.classList.remove('open'));
  },
  applySession() {
    Auth.check().then(s => {
      if (!s) return;
      const nameEl = document.getElementById('topbar-name');
      const avatarEl = document.getElementById('topbar-avatar');
      if (nameEl) nameEl.textContent = s.name;
      if (avatarEl) avatarEl.textContent = s.initials;
      if (s.isDemo || !SUPABASE_CONFIGURED) {
        const banner = document.getElementById('demo-banner');
        if (banner) banner.style.display = 'flex';
      }
      document.getElementById('logout-btn')?.addEventListener('click', () => Auth.logout());
    });
  },
  openModal(id)  { const m = document.getElementById(id); if (m) m.classList.add('open');    },
  closeModal(id) { const m = document.getElementById(id); if (m) m.classList.remove('open'); },
  fmt: {
    currency(n) { return '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 }); },
    number(n)   { return Number(n).toLocaleString('en-US'); },
    pct(n)      { return Number(n).toFixed(1) + '%'; },
    change(n)   { return (n >= 0 ? '+' : '') + Number(n).toFixed(1) + '%'; }
  },
  sortTable(table, col, dir) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    rows.sort((a, b) => {
      const av = a.cells[col]?.textContent.replace(/[$,%]/g,'').trim();
      const bv = b.cells[col]?.textContent.replace(/[$,%]/g,'').trim();
      const an = parseFloat(av), bn = parseFloat(bv);
      if (!isNaN(an) && !isNaN(bn)) return dir === 'asc' ? an - bn : bn - an;
      return dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    rows.forEach(r => tbody.appendChild(r));
  },
  initSortableTables() {
    document.querySelectorAll('table').forEach(table => {
      table.querySelectorAll('th').forEach((th, i) => {
        th.style.cursor = 'pointer';
        let dir = 'desc';
        th.addEventListener('click', () => {
          table.querySelectorAll('th').forEach(t => t.className = '');
          th.className = 'sort-' + dir;
          this.sortTable(table, i, dir);
          dir = dir === 'asc' ? 'desc' : 'asc';
        });
      });
    });
  },
  showSkeleton(container, count = 3) {
    container.innerHTML = Array(count).fill('<div class="skeleton skeleton-card" style="margin-bottom:12px"></div>').join('');
  },
  buildChart(ctx, type, labels, datasets, opts = {}) {
    return new Chart(ctx, {
      type, data: { labels, datasets },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { display: opts.legend ?? true, labels: { color: '#9898b8', font: { family: 'DM Sans', size: 12 }, padding: 16, usePointStyle: true, pointStyleWidth: 8 } },
          tooltip: { backgroundColor: '#1a1a2e', borderColor: 'rgba(255,255,255,0.1)', borderWidth: 1, titleColor: '#e8e8f2', bodyColor: '#9898b8', padding: 12, callbacks: { label: c => ` ${opts.prefix || ''}${UI.fmt.currency(c.raw).replace('$', opts.prefix === '$' ? '' : '')}` } }
        },
        scales: type !== 'doughnut' ? { x: { ticks: { color: '#55556a', font: { size: 11 }, maxTicksLimit: 8 }, grid: { color: 'rgba(255,255,255,0.04)', drawBorder: false } }, y: { ticks: { color: '#55556a', font: { size: 11 }, callback: v => opts.yPrefix ? opts.yPrefix + v.toLocaleString() : v.toLocaleString() }, grid: { color: 'rgba(255,255,255,0.06)', drawBorder: false } } } : {},
        interaction: { intersect: false, mode: 'index' }, ...opts.extra
      }
    });
  }
};

// ── CONNECTION HANDLERS ───────────────────────────────────
async function handleConnect(platform, formData) {
  await Connections.set(platform, formData);
  showToast(`${platform} connected successfully!`, 'success');
  setTimeout(() => location.reload(), 800);
}
async function handleDisconnect(platform) {
  if (confirm(`Disconnect ${platform}? Live data will switch to demo mode.`)) {
    await Connections.remove(platform);
    showToast(`${platform} disconnected`, 'warning');
    setTimeout(() => location.reload(), 600);
  }
}
async function testConnection(platform) {
  const btn = document.getElementById(`test-${platform.toLowerCase()}`);
  if (!btn) return;
  const orig = btn.textContent;
  btn.textContent = 'Testing...'; btn.disabled = true;
  await new Promise(r => setTimeout(r, 1500));
  btn.textContent = '✓ Connected'; btn.style.background = 'var(--success-dim)'; btn.style.color = 'var(--success)';
  setTimeout(() => { btn.textContent = orig; btn.disabled = false; btn.style = ''; }, 2000);
}

// ── TOAST ─────────────────────────────────────────────────
function showToast(msg, type = 'success') {
  const colors = { success: ['rgba(0,200,150,0.1)','rgba(0,200,150,0.3)','var(--success)'], warning: ['rgba(245,158,11,0.1)','rgba(245,158,11,0.3)','var(--warning)'], error: ['rgba(239,68,68,0.1)','rgba(239,68,68,0.3)','var(--danger)'] };
  const [bg, border, color] = colors[type] || colors.success;
  const t = document.createElement('div');
  t.style.cssText = `position:fixed;bottom:24px;right:24px;background:${bg};border:1px solid ${border};color:${color};padding:12px 20px;border-radius:10px;font-size:13px;font-weight:600;z-index:999;animation:fadeIn 0.3s ease both;font-family:var(--font-body)`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ── SESSION IDLE TIMEOUT ──────────────────────────────────
// Warns after 28 min inactivity, auto-logs out at 30 min.
// Skipped for demo account.
const IdleTimer = {
  WARN_AFTER:    28 * 60 * 1000,
  LOGOUT_AFTER:  30 * 60 * 1000,
  _timer:        null,
  _countdownTimer: null,
  _modal:        null,

  async start() {
    const session = await Auth.check();
    if (!session || session.isDemo) return;
    this._reset();
    ['mousemove','click','keydown','scroll','touchstart'].forEach(evt =>
      window.addEventListener(evt, () => this._reset(), { passive: true })
    );
  },

  _reset() {
    clearTimeout(this._timer);
    clearInterval(this._countdownTimer);
    if (this._modal) { this._modal.remove(); this._modal = null; }
    const bd = document.getElementById('ys-idle-backdrop');
    if (bd) bd.remove();
    this._timer = setTimeout(() => this._warn(), this.WARN_AFTER);
  },

  _warn() {
    if (this._modal) return;
    let secondsLeft = 120;

    if (!document.getElementById('ys-idle-styles')) {
      const style = document.createElement('style');
      style.id = 'ys-idle-styles';
      style.textContent = '#ys-idle-backdrop{position:fixed;inset:0;background:rgba(0,0,0,0.75);backdrop-filter:blur(4px);z-index:99998}#ys-idle-modal{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#13131f;border:1px solid rgba(255,255,255,0.12);border-radius:20px;padding:36px;max-width:400px;width:calc(100% - 40px);z-index:99999;text-align:center;box-shadow:0 30px 80px rgba(0,0,0,0.7)}#ys-idle-modal h3{font-family:var(--font-display,sans-serif);font-size:20px;font-weight:700;color:#fff;margin:0 0 12px}#ys-idle-modal p{font-size:14px;color:#9898b8;margin:0 0 8px;line-height:1.6}#ys-idle-countdown{font-size:40px;font-weight:900;font-family:var(--font-display,sans-serif);color:#e94560;margin:16px 0}.ys-idle-actions{display:flex;gap:10px;margin-top:20px}.ys-idle-stay{flex:1;background:#e94560;color:#fff;border:none;border-radius:8px;padding:12px;font-size:14px;font-weight:600;cursor:pointer}.ys-idle-logout{flex:1;background:rgba(255,255,255,0.05);color:#e8e8f2;border:1px solid rgba(255,255,255,0.12);border-radius:8px;padding:12px;font-size:14px;font-weight:500;cursor:pointer}';
      document.head.appendChild(style);
    }

    const backdrop = document.createElement('div');
    backdrop.id = 'ys-idle-backdrop';
    const modal = document.createElement('div');
    modal.id = 'ys-idle-modal';
    modal.innerHTML = '<h3>\u23F1 Session Expiring</h3><p>Your session will expire due to inactivity.</p><div id="ys-idle-countdown">' + secondsLeft + '</div><p style="font-size:12px;color:#55556a">You will be logged out automatically.</p><div class="ys-idle-actions"><button class="ys-idle-stay" id="ys-idle-stay-btn">Stay Logged In</button><button class="ys-idle-logout" id="ys-idle-logout-btn">Log Out Now</button></div>';

    document.body.appendChild(backdrop);
    document.body.appendChild(modal);
    this._modal = modal;

    document.getElementById('ys-idle-stay-btn').addEventListener('click', () => {
      backdrop.remove(); modal.remove(); this._modal = null; this._reset();
    });
    document.getElementById('ys-idle-logout-btn').addEventListener('click', () => Auth.logout());

    this._countdownTimer = setInterval(() => {
      secondsLeft--;
      const el = document.getElementById('ys-idle-countdown');
      if (el) el.textContent = secondsLeft;
      if (secondsLeft <= 0) { clearInterval(this._countdownTimer); Auth.logout(); }
    }, 1000);
  },

  stop() {
    clearTimeout(this._timer);
    clearInterval(this._countdownTimer);
    if (this._modal) { this._modal.remove(); this._modal = null; }
  }
};

// ── AUTO-INIT ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  UI.init();
  IdleTimer.start();
  // Expose config status to connect.html Supabase status card
  window.SUPABASE_CONFIG = { url: SUPABASE_URL, configured: SUPABASE_CONFIGURED };
});

// ══════════════════════════════════════════════════════════
// SUPABASE DATABASE SCHEMA
// Run this SQL in: supabase.com → your project → SQL Editor
// ══════════════════════════════════════════════════════════
/*
CREATE TABLE IF NOT EXISTS ys_connections (
  id           uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id      uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  platform     text NOT NULL,
  credentials  jsonb NOT NULL DEFAULT '{}',
  connected_at timestamptz DEFAULT now(),
  UNIQUE(user_id, platform)
);
ALTER TABLE ys_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own connections" ON ys_connections
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS ys_metrics (
  id         uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id    uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  platform   text NOT NULL,
  metrics    jsonb NOT NULL DEFAULT '{}',
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, platform)
);
ALTER TABLE ys_metrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own metrics" ON ys_metrics
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_connections_user ON ys_connections(user_id);
CREATE INDEX IF NOT EXISTS idx_metrics_user     ON ys_metrics(user_id);
*/
