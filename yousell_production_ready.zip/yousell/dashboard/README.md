# YouSell.Online — Client Dashboard

A full-stack client dashboard connecting Amazon, TikTok Shop, and Shopify accounts with real-time sales data.

---

## 🚀 Quick Start (Demo Mode)

1. Open `login.html` in your browser (or serve the folder — see below)
2. Login with the demo account:
   - **Email:** `demo@yousell.online`
   - **Password:** `YouSell2025`
3. Explore all pages with realistic mock data

---

## 📁 File Structure

```
dashboard/
├── login.html          # Authentication page
├── index.html          # Overview / combined dashboard
├── amazon.html         # Amazon SP-API analytics
├── tiktok.html         # TikTok Shop analytics
├── shopify.html        # Shopify Admin API analytics
├── connect.html        # Platform connection + how-to guides
├── reports.html        # Auto-generated reports list
├── settings.html       # Profile, notifications, security, billing
├── dashboard.css       # Full design system
├── dashboard.js        # Auth, API layer, mock data, UI helpers
├── layout.js           # Shared sidebar + topbar builder
├── proxy-server.js     # Node.js/Express CORS proxy (production)
├── package.json        # Proxy server dependencies
└── .env.example        # Environment variable template
```

---

## 🌐 Serving the Dashboard

### Option A — VS Code Live Server (simplest)
1. Open the `dashboard/` folder in VS Code
2. Install the "Live Server" extension
3. Right-click `login.html` → Open with Live Server

### Option B — Python (no install)
```bash
cd dashboard/
python3 -m http.server 8080
# Visit: http://localhost:8080/login.html
```

### Option C — Deploy to Netlify (production)
1. Drag the entire `dashboard/` folder to [netlify.com/drop](https://netlify.com/drop)
2. Done. You get a live URL instantly.
3. Point `dashboard.yousell.online` DNS to it.

---

## 🔌 Connecting Real API Data

### Step 1 — Set Up the Proxy Server
```bash
cd dashboard/
npm install
cp .env.example .env
# Fill in your API keys in .env
node proxy-server.js
# Proxy running on http://localhost:3001
```

### Step 2 — Connect Each Platform

Go to **Connections** page in the dashboard and follow the in-dashboard guides, or:

#### Amazon SP-API
1. Visit [sellercentral.amazon.com/apps/manage](https://sellercentral.amazon.com/apps/manage)
2. Create a Self-Authorised SP-API app
3. Copy Client ID, Client Secret, Refresh Token, Seller ID
4. Paste into the Connect modal

#### TikTok Shop
1. Visit [partner.tiktokshop.com](https://partner.tiktokshop.com)
2. Create a Self-Developed App
3. Generate access token via OAuth
4. Copy App Key, App Secret, Access Token, Shop ID
5. Paste into the Connect modal

#### Shopify
1. Go to Shopify Admin → Settings → Apps → Develop Apps
2. Create a Custom App named "YouSell Dashboard"
3. Set scopes: `read_orders`, `read_products`, `read_customers`, `read_analytics`
4. Install app and copy the Admin API Access Token
5. Paste token + shop domain into the Connect modal

---

## 🔒 Security Notes

- In demo mode, credentials are stored in `localStorage` (browser only)
- For production: store credentials server-side in an encrypted database
- Never expose API secrets in client-side JS in production
- The `proxy-server.js` is designed to hold secrets server-side
- Set `ALLOWED_ORIGIN` in `.env` to your dashboard domain in production

---

## 🎨 Design System

| Token | Value |
|-------|-------|
| Background | `#0d0d14` |
| Card | `rgba(255,255,255,0.03)` |
| Accent Red | `#e94560` |
| Success | `#00c896` |
| Font Display | Outfit 800 |
| Font Body | DM Sans 400/500 |

---

## 📞 Support

**YouSell.Online** · admin@yousell.online · +1 (306) 800-5166
