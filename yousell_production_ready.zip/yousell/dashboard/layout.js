// Shared layout builder
function buildLayout(pageId, title, subtitle) {
  const navItems = [
    { id: 'overview', icon: '▦', label: 'Overview', href: 'index.html', tip: 'Overview' },
    { id: 'amazon', icon: '📦', label: 'Amazon', href: 'amazon.html', tip: 'Amazon' },
    { id: 'tiktok', icon: '🎵', label: 'TikTok Shop', href: 'tiktok.html', tip: 'TikTok' },
    { id: 'shopify', icon: '🛍️', label: 'Shopify', href: 'shopify.html', tip: 'Shopify' },
    { id: 'sep1', type: 'sep', label: 'Management' },
    { id: 'connect', icon: '🔗', label: 'Connections', href: 'connect.html', tip: 'Connect' },
    { id: 'reports', icon: '📄', label: 'Reports', href: 'reports.html', tip: 'Reports' },
    { id: 'sep2', type: 'sep', label: 'Account' },
    { id: 'settings', icon: '⚙️', label: 'Settings', href: 'settings.html', tip: 'Settings' },
  ];

  const navHTML = navItems.map(item => {
    if (item.type === 'sep') return `<div class="nav-section"><div class="nav-section-label">${item.label}</div>`;
    return `<a href="${item.href}" class="nav-item ${item.id === pageId ? 'active' : ''}" data-tip="${item.tip}">
      <span class="nav-icon">${item.icon}</span>
      <span class="nav-label">${item.label}</span>
    </a>`;
  }).join('');

  const now = new Date().toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric' });

  document.getElementById('app-root').innerHTML = `
    <div class="mobile-overlay" id="mobile-overlay"></div>
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-header">
        <span class="sidebar-logo"><a href="../index.html" style="text-decoration:none"><span style="color:var(--red)">You</span>Sell.Online</a></span>
        <button class="sidebar-toggle" id="sidebar-toggle">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section"><div class="nav-section-label">Platforms</div>
          <a href="index.html" class="nav-item ${pageId==='overview'?'active':''}" data-tip="Overview"><span class="nav-icon">▦</span><span class="nav-label">Overview</span></a>
          <a href="amazon.html" class="nav-item ${pageId==='amazon'?'active':''}" data-tip="Amazon"><span class="nav-icon">📦</span><span class="nav-label">Amazon</span></a>
          <a href="tiktok.html" class="nav-item ${pageId==='tiktok'?'active':''}" data-tip="TikTok Shop"><span class="nav-icon">🎵</span><span class="nav-label">TikTok Shop</span></a>
          <a href="shopify.html" class="nav-item ${pageId==='shopify'?'active':''}" data-tip="Shopify"><span class="nav-icon">🛍️</span><span class="nav-label">Shopify</span></a>
        </div>
        <div class="nav-section"><div class="nav-section-label">Management</div>
          <a href="connect.html" class="nav-item ${pageId==='connect'?'active':''}" data-tip="Connections"><span class="nav-icon">🔗</span><span class="nav-label">Connections</span></a>
          <a href="reports.html" class="nav-item ${pageId==='reports'?'active':''}" data-tip="Reports"><span class="nav-icon">📄</span><span class="nav-label">Reports</span></a>
        </div>
        <div class="nav-section"><div class="nav-section-label">Account</div>
          <a href="settings.html" class="nav-item ${pageId==='settings'?'active':''}" data-tip="Settings"><span class="nav-icon">⚙️</span><span class="nav-label">Settings</span></a>
        </div>
      </nav>
      <div class="sidebar-footer">
        <button class="nav-item" id="logout-btn" data-tip="Logout" style="width:100%;background:none;border:none;text-align:left">
          <span class="nav-icon">🚪</span><span class="nav-label">Sign Out</span>
        </button>
      </div>
    </aside>
    <div class="main" id="main-content">
      <div id="demo-banner" class="demo-banner" style="display:none">
        ⚡ <strong>Demo Mode</strong> — Showing sample data. <a href="connect.html">Connect your accounts</a> to see live stats.
      </div>
      <header class="topbar">
        <button class="topbar-btn" id="mobile-menu-btn" style="display:none">☰</button>
        <div class="topbar-title">${title} <span>${subtitle || now}</span></div>
        <div class="topbar-actions">
          <div style="position:relative">
            <button class="topbar-btn" id="notif-btn">
              🔔
              <span class="notif-dot"></span>
            </button>
            <div class="notif-dropdown" id="notif-dropdown">
              <div class="notif-header"><span class="notif-title">Notifications</span><span style="font-size:11px;color:var(--red);cursor:pointer">Mark all read</span></div>
              <div class="notif-item notif-unread">
                <div class="notif-item-icon" style="background:rgba(255,153,0,0.1)">📦</div>
                <div><div class="notif-text"><strong>New Amazon order</strong> — Kitchen Organiser ×2</div><div class="notif-time">2 min ago</div></div>
              </div>
              <div class="notif-item notif-unread">
                <div class="notif-item-icon" style="background:rgba(255,0,80,0.08)">🎵</div>
                <div><div class="notif-text"><strong>Creator video</strong> — 12K views in 1hr</div><div class="notif-time">14 min ago</div></div>
              </div>
              <div class="notif-item">
                <div class="notif-item-icon" style="background:rgba(0,200,100,0.08)">🛍️</div>
                <div><div class="notif-text"><strong>Shopify order #1847</strong> — $60.00</div><div class="notif-time">28 min ago</div></div>
              </div>
              <div class="notif-item">
                <div class="notif-item-icon" style="background:rgba(245,158,11,0.1)">📈</div>
                <div><div class="notif-text"><strong>Weekly report</strong> ready to download</div><div class="notif-time">3 hr ago</div></div>
              </div>
              <div style="padding:10px 16px;text-align:center"><a href="reports.html" style="font-size:12px;color:var(--red)">View all reports →</a></div>
            </div>
          </div>
          <a href="connect.html" class="topbar-btn" title="Platform Connections">🔗</a>
          <div style="display:flex;align-items:center;gap:8px;margin-left:4px">
            <div>
              <div class="topbar-name" id="topbar-name">Loading...</div>
              <div class="topbar-role">Client Account</div>
            </div>
            <div class="topbar-avatar" id="topbar-avatar">??</div>
          </div>
        </div>
      </header>
      <div class="page-content" id="page-content"></div>
    </div>`;

  // Show mobile menu button on small screens
  if (window.innerWidth <= 960) {
    document.getElementById('mobile-menu-btn').style.display = 'flex';
  }
  window.addEventListener('resize', () => {
    const btn = document.getElementById('mobile-menu-btn');
    if (btn) btn.style.display = window.innerWidth <= 960 ? 'flex' : 'none';
  });
}
