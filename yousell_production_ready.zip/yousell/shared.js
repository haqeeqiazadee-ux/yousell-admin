// Shared JS for all YouSell pages

// ══════════════════════════════════════════════════════
// ANALYTICS — Consent-gated (GDPR/CCPA compliant)
// Replace placeholder IDs before going live:
// ══════════════════════════════════════════════════════

// REPLACE G-XXXXXXXXXX with your Google Analytics 4 Measurement ID
// Find it at: analytics.google.com → Admin → Property → Data Streams → Web Stream
window.GA_ID = 'G-XXXXXXXXXX';

// REPLACE with your Meta Pixel ID from business.facebook.com → Events Manager → Pixels
window.FB_PIXEL_ID = 'XXXXXXXXXXXXXXXXXX';

// REPLACE with your TikTok Pixel ID from ads.tiktok.com → Assets → Events → Web Events
window.TIKTOK_PIXEL_ID = 'XXXXXXXXXXXXXXXXXX';

const isDashboardPage = window.location.pathname.includes('/dashboard/');

function loadGA4() {
  if (isDashboardPage || window._ga4Loaded) return;
  if (!window.GA_ID || window.GA_ID === 'G-XXXXXXXXXX') return;
  window._ga4Loaded = true;
  const script = document.createElement('script');
  script.async = true;
  script.src = 'https://www.googletagmanager.com/gtag/js?id=' + window.GA_ID;
  document.head.appendChild(script);
  window.dataLayer = window.dataLayer || [];
  function gtag(){ window.dataLayer.push(arguments); }
  window.gtag = gtag;
  gtag('js', new Date());
  gtag('config', window.GA_ID, { anonymize_ip: true });
  // Fire pricing_view event if on pricing page
  if (window.location.pathname.includes('/pricing/')) {
    gtag('event', 'pricing_view');
  }
}

function loadMetaPixel() {
  if (isDashboardPage || window._fbLoaded) return;
  if (!window.FB_PIXEL_ID || window.FB_PIXEL_ID === 'XXXXXXXXXXXXXXXXXX') return;
  window._fbLoaded = true;
  !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', window.FB_PIXEL_ID);
  fbq('track', 'PageView');
}

function loadTikTokPixel() {
  if (isDashboardPage || window._ttLoaded) return;
  if (!window.TIKTOK_PIXEL_ID || window.TIKTOK_PIXEL_ID === 'XXXXXXXXXXXXXXXXXX') return;
  window._ttLoaded = true;
  !function(w,d,t){w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=['page','track','identify','instances','debug','on','off','once','ready','alias','group','enableCookie','disableCookie'];ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e};ttq.load=function(e,n){var i='https://analytics.tiktok.com/i18n/pixel/events.js';ttq._i=ttq._i||{};ttq._i[e]=[];ttq._i[e]._u=i;ttq._t=ttq._t||{};ttq._t[e]=+new Date;ttq._o=ttq._o||{};ttq._o[e]=n||{};var o=document.createElement('script');o.type='text/javascript';o.async=!0;o.src=i+'?sdkid='+e+'&lib='+t;var a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(o,a)};ttq.load(window.TIKTOK_PIXEL_ID);ttq.page()}(window,document,'ttq');
}

function initAnalytics() {
  if (isDashboardPage) return;
  var consent = null;
  try { consent = JSON.parse(localStorage.getItem('ys_cookie_consent')); } catch(e) {}

  if (consent && consent.analytics) loadGA4();
  if (consent && consent.marketing) {
    loadMetaPixel();
    loadTikTokPixel();
  }
}

// Re-check consent when user updates cookie prefs
document.addEventListener('consentUpdated', function(e) {
  if (!e.detail) return;
  if (e.detail.analytics) loadGA4();
  if (e.detail.marketing) { loadMetaPixel(); loadTikTokPixel(); }
});

// Track CTA clicks
document.addEventListener('click', function(e) {
  var btn = e.target.closest('.nav-btn-primary, .btn-primary');
  if (btn && typeof gtag === 'function') {
    gtag('event', 'cta_click', { button_text: btn.textContent.trim().slice(0, 50) });
  }
});

// Init on load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAnalytics);
} else {
  initAnalytics();
}

// ══════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', function() {
  // Navbar scroll
  const nav = document.getElementById('main-nav');
  if (nav) window.addEventListener('scroll', () => nav.classList.toggle('scrolled', window.scrollY > 20), {passive:true});

  // Mobile menu
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileClose = document.getElementById('mobile-close');
  if (hamburger) hamburger.addEventListener('click', () => { mobileMenu.classList.add('open'); document.body.style.overflow = 'hidden'; });
  if (mobileClose) mobileClose.addEventListener('click', () => { mobileMenu.classList.remove('open'); document.body.style.overflow = ''; });

  // Announce bar close
  const announceClose = document.querySelector('.announce-close');
  const announceBar = document.getElementById('announce-bar');
  if (announceClose && announceBar) announceClose.addEventListener('click', () => announceBar.style.display = 'none');

  // Scroll reveal
  const reveals = document.querySelectorAll('.reveal');
  const revealObs = new IntersectionObserver(entries => entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); revealObs.unobserve(e.target); } }), {threshold:0.08, rootMargin:'0px 0px -40px 0px'});
  reveals.forEach(el => revealObs.observe(el));

  // FAQ
  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', function() {
      const ans = this.nextElementSibling;
      const isOpen = this.classList.contains('open');
      document.querySelectorAll('.faq-q.open').forEach(oq => { oq.classList.remove('open'); oq.nextElementSibling.classList.remove('open'); });
      if (!isOpen) { this.classList.add('open'); ans.classList.add('open'); }
    });
  });

  // Counter animation
  function animCount(el, target, dur, isDecimal) {
    const start = performance.now();
    const update = t => { const p = Math.min((t-start)/dur,1); const e = 1-Math.pow(1-p,3); el.textContent = isDecimal ? (e*target).toFixed(1) : Math.floor(e*target); if(p<1) requestAnimationFrame(update); else el.textContent = isDecimal ? target.toFixed(1) : target; };
    requestAnimationFrame(update);
  }
  const countObs = new IntersectionObserver(entries => entries.forEach(e => { if(e.isIntersecting) { const el=e.target, t=parseFloat(el.dataset.count), isD=String(t).includes('.'); animCount(el,t,1800,isD); countObs.unobserve(el); } }), {threshold:0.5});
  document.querySelectorAll('[data-count]').forEach(el => countObs.observe(el));
});
